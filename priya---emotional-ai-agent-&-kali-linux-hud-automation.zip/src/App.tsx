import React, { useState, useEffect, useRef } from 'react';
import {
  Zap,
  Terminal,
  Heart,
  FolderTree,
  Camera,
  Mic,
  MicOff,
  Send,
  Sparkles,
  Shield,
  Volume2,
  VolumeX,
  Layers,
  MousePointer,
  CheckCircle2,
} from 'lucide-react';
import { EmotionalAvatar, EmotionState } from './components/EmotionalAvatar';
import { KaliTerminal, TerminalEntry } from './components/KaliTerminal';
import { KaliLaunchAutomationDeck } from './components/KaliLaunchAutomationDeck';
import { PriyaCareHub } from './components/PriyaCareHub';
import { MarkLviExplorer } from './components/MarkLviExplorer';
import { CameraVisionModal } from './components/CameraVisionModal';
import { SystemTelemetryHUD } from './components/SystemTelemetryHUD';
import { KaliAppLauncher } from './components/KaliAppLauncher';
import { MouseControlHUD, MouseEventState } from './components/MouseControlHUD';
import { priyaVoice } from './utils/speech';

interface Message {
  id: string;
  sender: 'user' | 'priya';
  text: string;
  emotion?: EmotionState;
  careInsight?: string;
  actionExecuted?: string;
  executionResult?: {
    command: string;
    stdout: string;
    stderr?: string;
    exitCode: number;
    toolName?: string;
  };
  mouseResult?: {
    action: string;
    x: number;
    y: number;
    target: string;
    feedback: string;
  };
  timestamp: string;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<
    'automation' | 'hud' | 'terminal' | 'apps' | 'mouse' | 'care' | 'explorer'
  >('automation');
  const [emotion, setEmotion] = useState<EmotionState>('caring');
  const [osMode, setOsMode] = useState<'kali' | 'windows'>('kali');
  const [sudoEnabled, setSudoEnabled] = useState<boolean>(true);
  const [voiceEnabled, setVoiceEnabled] = useState<boolean>(true);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [visemeAperture, setVisemeAperture] = useState<number>(0);
  const [cameraModalOpen, setCameraModalOpen] = useState<boolean>(false);
  const [isListening, setIsListening] = useState<boolean>(false);
  const [inputMessage, setInputMessage] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  // Mouse control state
  const [mouseState, setMouseState] = useState<MouseEventState>({
    x: 520,
    y: 350,
    action: 'idle',
    targetLabel: 'Ready for operator order',
    isControlling: false,
  });

  // Synced terminal entries across HUD and Terminal Deck
  const [terminalEntries, setTerminalEntries] = useState<TerminalEntry[]>([]);

  // User state
  const [userName, setUserName] = useState('Amit');
  const [waterIntake, setWaterIntake] = useState(1400);
  const [pomodoroCount, setPomodoroCount] = useState(4);
  const [pushupCount, setPushupCount] = useState(30);

  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'msg-1',
      sender: 'priya',
      text: "Hello Amit! I've updated your Mark LVI architecture with full Kali Linux launch automation. All 4 gates are armed:\n1. Safe Linux environment check (bypassing winreg/win32gui shims)\n2. Playwright Chromium browser automation with automated Google Search\n3. VS Code hook & /root/priya_loot directory hierarchy\n4. Zero-crash subprocess & headless display error trapping.\n\nI'm ready for your orders, scans, or personal conversation!",
      emotion: 'caring',
      careInsight: "All launch gates verified. Ready to inspect code, run Google searches, or dispatch tools.",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const recognitionRef = useRef<any>(null);

  // Auto-scroll chat
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isProcessing]);

  // Initial welcome voice
  useEffect(() => {
    const timer = setTimeout(() => {
      if (voiceEnabled) {
        priyaVoice.speak(
          "Priya Mark LVI online, Amit. Kali Linux launch automation initialized. Playwright Chromium and VS Code hooks are active.",
          'caring',
          {
            onStart: () => setIsSpeaking(true),
            onEnd: () => setIsSpeaking(false),
            onViseme: (v) => setVisemeAperture(v),
          }
        );
      }
    }, 1200);
    return () => clearTimeout(timer);
  }, []);

  // Speech Recognition setup
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const SpeechRecognition =
        (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        const recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = 'en-US';
        recognition.onresult = (event: any) => {
          const transcript = event.results[0][0].transcript;
          setInputMessage(transcript);
          setIsListening(false);
          handleSendMessage(transcript);
        };
        recognition.onerror = () => setIsListening(false);
        recognition.onend = () => setIsListening(false);
        recognitionRef.current = recognition;
      }
    }
  }, []);

  const toggleSpeechRecognition = () => {
    if (!recognitionRef.current) {
      alert('Speech recognition is not supported in this browser.');
      return;
    }
    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      try {
        recognitionRef.current.start();
        setIsListening(true);
      } catch (err) {
        console.error(err);
      }
    }
  };

  const executeTerminalFromHUD = async (cmd: string) => {
    const res = await fetch('/api/terminal/run', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        command: cmd,
        osMode,
        sudoMode: sudoEnabled,
      }),
    });
    return res.json();
  };

  const handleExecuteMouseAction = async (
    action: 'move' | 'click' | 'double_click' | 'drag' | 'scroll',
    x: number,
    y: number,
    targetLabel?: string
  ) => {
    setMouseState({
      x,
      y,
      action,
      targetLabel: targetLabel || `Coordinates (${x}, ${y})`,
      isControlling: true,
    });
    const res = await fetch('/api/mouse/control', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action,
        x,
        y,
        target: targetLabel,
      }),
    });
    const data = await res.json();
    setTimeout(() => {
      setMouseState((prev) => ({ ...prev, isControlling: false }));
    }, 1200);
    return data;
  };

  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend ?? inputMessage).trim();
    if (!query || isProcessing) return;
    setInputMessage('');

    const userMsg: Message = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    setMessages((prev) => [...prev, userMsg]);
    setIsProcessing(true);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          history: messages.slice(-5).map((m) => ({
            role: m.sender,
            content: m.text,
          })),
          context: {
            osMode,
            sudoMode: sudoEnabled,
            userName,
            waterIntake,
            pomodoroCount,
          },
        }),
      });
      const data = await res.json();
      const replyEmotion = (data.emotion as EmotionState) || 'caring';
      setEmotion(replyEmotion);

      let actionExecutedText = '';
      let execResult: any = null;
      let mouseResObj: any = null;

      // Check if Priya dispatched mouse control
      if (data.action?.type === 'mouse_control' || data.action?.mouseAction) {
        const mouseAction = data.action.mouseAction || 'click';
        const posX = data.action.x ?? 520;
        const posY = data.action.y ?? 380;
        const targetLabel = data.action.target || 'Kali Workspace';
        actionExecutedText = `Mouse Order: ${mouseAction.toUpperCase()} on ${targetLabel}`;
        const mouseData = await handleExecuteMouseAction(mouseAction, posX, posY, targetLabel);
        mouseResObj = {
          action: mouseAction,
          x: posX,
          y: posY,
          target: targetLabel,
          feedback: mouseData.feedback || `Mouse dispatched to (${posX}, ${posY})`,
        };
      } else if (data.action?.command) {
        actionExecutedText = `Root Command: ${data.action.command}`;
        try {
          const runRes = await executeTerminalFromHUD(data.action.command);
          execResult = {
            command: data.action.command,
            stdout: runRes.stdout || '',
            stderr: runRes.stderr || '',
            exitCode: runRes.exitCode ?? 0,
            toolName: data.action.toolName,
          };
          setTerminalEntries((prev) => [
            ...prev,
            {
              id: `act-${Date.now()}`,
              command: data.action.command,
              output: runRes.stdout || '',
              stderr: runRes.stderr,
              exitCode: runRes.exitCode ?? 0,
              timestamp: new Date().toLocaleTimeString(),
              osMode,
              isSudo: sudoEnabled,
              priyaNote: `Priya auto-executed for Amit: ${data.action.toolName || data.action.command}`,
            },
          ]);
        } catch (execErr: any) {
          execResult = {
            command: data.action.command,
            stdout: '',
            stderr: execErr.message,
            exitCode: 1,
          };
        }
      }

      const priyaMsg: Message = {
        id: `priya-${Date.now()}`,
        sender: 'priya',
        text: data.reply || "I'm with you, Amit.",
        emotion: replyEmotion,
        careInsight: data.careInsight,
        actionExecuted: actionExecutedText || undefined,
        executionResult: execResult || undefined,
        mouseResult: mouseResObj || undefined,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, priyaMsg]);

      if (voiceEnabled) {
        priyaVoice.speak(data.reply, replyEmotion, {
          onStart: () => setIsSpeaking(true),
          onEnd: () => setIsSpeaking(false),
          onViseme: (v) => setVisemeAperture(v),
        });
      }
    } catch (err: any) {
      setMessages((prev) => [
        ...prev,
        {
          id: `priya-err-${Date.now()}`,
          sender: 'priya',
          text: `Neural communication delay: ${err.message}. Everything else remains secure.`,
          emotion: 'protective',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#030712] text-slate-100 flex flex-col font-sans select-none relative">
      {/* Background Cyber Grid Accent */}
      <div className="absolute inset-0 scanlines opacity-30 pointer-events-none z-0" />

      {/* Floating Mouse Overlay Indicator */}
      {mouseState.isControlling && (
        <div className="fixed top-16 right-6 z-50 p-2.5 rounded-xl bg-amber-950/90 border border-amber-500 shadow-2xl flex items-center gap-3 backdrop-blur-md animate-bounce font-mono">
          <MousePointer className="w-5 h-5 text-amber-400 animate-pulse" />
          <div className="text-xs">
            <span className="font-bold text-amber-300 block">
              PRIYA CONTROLLING MOUSE // {mouseState.action.toUpperCase()}
            </span>
            <span className="text-[10px] text-gray-300">
              Target: {mouseState.targetLabel} ({mouseState.x}, {mouseState.y})
            </span>
          </div>
        </div>
      )}

      {/* Top Navbar */}
      <header className="relative z-10 bg-gray-950/90 border-b border-cyan-900/40 px-4 py-2.5 backdrop-blur-md flex flex-wrap items-center justify-between gap-3">
        {/* Brand / Agent Identity */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-600 via-pink-500 to-amber-500 p-0.5 shadow-lg shadow-cyan-500/20">
            <div className="w-full h-full bg-gray-950 rounded-[10px] flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-pink-400" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base font-bold tracking-wider font-hud text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-pink-300 to-amber-300">
                PRIYA // MARK LVI
              </h1>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-pink-950/80 text-pink-300 border border-pink-700/60 font-semibold">
                KALI AUTOMATED
              </span>
            </div>
            <p className="text-[11px] font-mono text-gray-400">
              Personal Companion &bull; Root Kali Operator &bull; Partnered with {userName}
            </p>
          </div>
        </div>

        {/* Global Nav Tabs */}
        <nav className="flex items-center gap-1.5 bg-gray-900/80 p-1 rounded-xl border border-gray-800 font-mono text-xs overflow-x-auto">
          <button
            onClick={() => setActiveTab('automation')}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all ${
              activeTab === 'automation'
                ? 'bg-gradient-to-r from-cyan-600 to-emerald-600 text-black font-bold shadow-sm'
                : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            <Zap className={`w-3.5 h-3.5 ${activeTab === 'automation' ? 'text-black' : 'text-cyan-400'}`} />
            <span>LAUNCH AUTOMATION</span>
          </button>
          <button
            onClick={() => setActiveTab('hud')}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all ${
              activeTab === 'hud'
                ? 'bg-cyan-500/20 border border-cyan-400 text-cyan-200 font-bold shadow-sm'
                : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>HUD &amp; DIALOGUE</span>
          </button>
          <button
            onClick={() => setActiveTab('terminal')}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all ${
              activeTab === 'terminal'
                ? 'bg-amber-500/20 border border-amber-400 text-amber-200 font-bold shadow-sm'
                : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            <Terminal className="w-3.5 h-3.5 text-amber-400" />
            <span>KALI TERMINAL</span>
          </button>
          <button
            onClick={() => setActiveTab('apps')}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all ${
              activeTab === 'apps'
                ? 'bg-red-500/20 border border-red-400 text-red-200 font-bold shadow-sm'
                : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5 text-red-400" />
            <span>KALI APPS</span>
          </button>
          <button
            onClick={() => setActiveTab('mouse')}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all ${
              activeTab === 'mouse'
                ? 'bg-yellow-500/20 border border-yellow-400 text-yellow-200 font-bold shadow-sm'
                : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            <MousePointer className="w-3.5 h-3.5 text-yellow-400" />
            <span>MOUSE CONTROL</span>
          </button>
          <button
            onClick={() => setActiveTab('care')}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all ${
              activeTab === 'care'
                ? 'bg-pink-500/20 border border-pink-400 text-pink-200 font-bold shadow-sm'
                : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            <Heart className="w-3.5 h-3.5 text-pink-400" />
            <span>CARE &amp; LIFE</span>
          </button>
          <button
            onClick={() => setActiveTab('explorer')}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all ${
              activeTab === 'explorer'
                ? 'bg-blue-500/20 border border-blue-400 text-blue-200 font-bold shadow-sm'
                : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            <FolderTree className="w-3.5 h-3.5 text-blue-400" />
            <span>PROJECT FILES (.ZIP)</span>
          </button>
        </nav>

        {/* Quick Toggles */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setCameraModalOpen(true)}
            className="p-1.5 rounded-lg bg-gray-900 border border-cyan-800/60 text-cyan-300 hover:bg-cyan-950 transition-colors flex items-center gap-1 text-xs font-mono"
            title="Open Camera & Vision Perception"
          >
            <Camera className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden lg:inline text-[11px]">VISION</span>
          </button>
          <button
            onClick={() => {
              const next = !voiceEnabled;
              setVoiceEnabled(next);
              if (!next) priyaVoice.cancel();
            }}
            className="p-1.5 rounded-lg bg-gray-900 border border-gray-800 text-gray-300 hover:text-cyan-400 transition-colors"
            title={voiceEnabled ? 'Mute Voice' : 'Unmute Voice'}
          >
            {voiceEnabled ? (
              <Volume2 className="w-4 h-4 text-cyan-400" />
            ) : (
              <VolumeX className="w-4 h-4 text-gray-500" />
            )}
          </button>
          <div className="flex items-center gap-1.5 bg-gray-900/90 border border-emerald-600/50 rounded-lg px-2.5 py-1 text-[11px] font-mono text-emerald-300">
            <Shield className="w-3.5 h-3.5 text-emerald-400" />
            <span className="font-bold">ROOT // {osMode.toUpperCase()}</span>
          </div>
        </div>
      </header>

      {/* Main Interactive Stage */}
      <main className="relative z-10 flex-1 p-3 sm:p-4 max-w-7xl mx-auto w-full flex flex-col gap-3">
        {/* Sub-header Telemetry Banner */}
        <SystemTelemetryHUD osMode={osMode} />

        {/* View Routing */}
        {activeTab === 'automation' && (
          <KaliLaunchAutomationDeck
            onRunTerminalCommand={executeTerminalFromHUD}
            onAskPriya={(prompt) => {
              setActiveTab('hud');
              handleSendMessage(prompt);
            }}
          />
        )}

        {activeTab === 'hud' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 flex-1">
            {/* Left 5 Cols: Priya Avatar */}
            <div className="lg:col-span-5 flex flex-col gap-3">
              <EmotionalAvatar
                emotion={emotion}
                onEmotionChange={(emo) => {
                  setEmotion(emo);
                  priyaVoice.speak(`Emotional resonance calibrated to ${emo} mode, Amit.`, emo);
                }}
                isSpeaking={isSpeaking}
                visemeAperture={visemeAperture}
                voiceEnabled={voiceEnabled}
                onToggleVoice={() => {
                  const next = !voiceEnabled;
                  setVoiceEnabled(next);
                  if (!next) priyaVoice.cancel();
                }}
              />

              {/* Quick Launch & Action Triggers in HUD */}
              <div className="bg-gray-950/80 border border-cyan-900/40 rounded-2xl p-3 shadow-xl backdrop-blur-md font-mono">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                    <Zap className="w-3.5 h-3.5 text-amber-400" />
                    <span>LAUNCH AUTOMATION SHORTCUTS</span>
                  </span>
                  <span className="text-[10px] text-gray-500">Root Commands</span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <button
                    onClick={() =>
                      handleSendMessage(
                        'Priya, run the launch automation self-test suite (test_launch.py) and report results.'
                      )
                    }
                    className="p-2 rounded-lg bg-gray-900/80 border border-cyan-900/50 hover:border-amber-400 hover:bg-amber-950/20 text-left text-gray-300 hover:text-amber-200 transition-all"
                  >
                    <span className="font-bold text-amber-300 block text-[11px]">
                      Test 4 Launch Gates
                    </span>
                    <span className="text-[10px] text-gray-400">Run test_launch.py</span>
                  </button>
                  <button
                    onClick={() =>
                      handleSendMessage(
                        'Priya, initialize Playwright Chromium and perform an automated Google search for CVE-2024 exploits.'
                      )
                    }
                    className="p-2 rounded-lg bg-gray-900/80 border border-cyan-900/50 hover:border-blue-400 hover:bg-blue-950/20 text-left text-gray-300 hover:text-blue-200 transition-all"
                  >
                    <span className="font-bold text-blue-300 block text-[11px]">
                      Playwright Search
                    </span>
                    <span className="text-[10px] text-gray-400">Chromium --no-sandbox</span>
                  </button>
                  <button
                    onClick={() =>
                      handleSendMessage(
                        'Priya, hook Visual Studio Code to /root/priya_loot with --reuse-window and check directory structure.'
                      )
                    }
                    className="p-2 rounded-lg bg-gray-900/80 border border-cyan-900/50 hover:border-purple-400 hover:bg-purple-950/20 text-left text-gray-300 hover:text-purple-200 transition-all"
                  >
                    <span className="font-bold text-purple-300 block text-[11px]">
                      Hook VS Code &amp; Loot
                    </span>
                    <span className="text-[10px] text-gray-400">code /root/priya_loot</span>
                  </button>
                  <button
                    onClick={() =>
                      handleSendMessage(
                        'Priya, verify how you bypass winreg and win32gui without throwing ModuleNotFoundError.'
                      )
                    }
                    className="p-2 rounded-lg bg-gray-900/80 border border-cyan-900/50 hover:border-emerald-400 hover:bg-emerald-950/20 text-left text-gray-300 hover:text-emerald-200 transition-all"
                  >
                    <span className="font-bold text-emerald-300 block text-[11px]">
                      Check Windows Shims
                    </span>
                    <span className="text-[10px] text-gray-400">sys.modules mock trap</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Right 7 Cols: Interactive Dialogue */}
            <div className="lg:col-span-7 flex flex-col bg-gray-950/90 border border-cyan-900/40 rounded-2xl overflow-hidden shadow-2xl backdrop-blur-md h-[680px] font-mono">
              <div className="p-3 bg-gray-900/90 border-b border-cyan-900/40 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
                  <span className="text-xs font-bold text-cyan-300">
                    PRIYA NEURAL DIALOGUE &bull; LAUNCH SENTINEL
                  </span>
                </div>
                <div className="flex items-center gap-2 text-xs text-gray-400">
                  <span>Affinity: 96%</span>
                  <span>&bull;</span>
                  <span className="capitalize text-pink-300">{emotion}</span>
                </div>
              </div>

              {/* Message List */}
              <div className="flex-1 p-4 overflow-y-auto space-y-3.5 bg-[#030712] select-text text-xs">
                {messages.map((msg) => {
                  const isPriya = msg.sender === 'priya';
                  return (
                    <div
                      key={msg.id}
                      className={`flex flex-col ${isPriya ? 'items-start' : 'items-end'}`}
                    >
                      <div className="flex items-center gap-1.5 mb-1 text-[10px] text-gray-500">
                        <span>{isPriya ? 'PRIYA' : userName.toUpperCase()}</span>
                        <span>•</span>
                        <span>{msg.timestamp}</span>
                        {isPriya && msg.emotion && (
                          <span className="px-1.5 py-0.2 rounded bg-pink-950 text-pink-300 border border-pink-800 uppercase">
                            {msg.emotion}
                          </span>
                        )}
                      </div>
                      <div
                        className={`max-w-[85%] rounded-2xl p-3 leading-relaxed shadow-md ${
                          isPriya
                            ? 'bg-gray-900/95 border border-cyan-900/60 text-cyan-50 rounded-tl-sm'
                            : 'bg-cyan-600 text-black font-semibold rounded-tr-sm'
                        }`}
                      >
                        <p className="whitespace-pre-wrap">{msg.text}</p>
                        {msg.actionExecuted && (
                          <div className="mt-2 pt-2 border-t border-cyan-800/40 text-[11px] text-amber-300 flex items-center gap-1.5 font-bold">
                            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                            <span>{msg.actionExecuted}</span>
                          </div>
                        )}
                        {msg.executionResult && (
                          <div className="mt-2.5 rounded-xl bg-black/90 border border-cyan-800/80 p-2.5 text-xs shadow-inner">
                            <div className="flex items-center justify-between pb-1.5 border-b border-gray-800 mb-2">
                              <span className="text-cyan-300 font-bold text-[11px] flex items-center gap-1">
                                <Terminal className="w-3 h-3 text-cyan-400" />
                                <span>{msg.executionResult.command}</span>
                              </span>
                              <span
                                className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                                  msg.executionResult.exitCode === 0
                                    ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                                    : 'bg-red-950 text-red-300 border border-red-800'
                                }`}
                              >
                                EXIT {msg.executionResult.exitCode}
                              </span>
                            </div>
                            {msg.executionResult.stdout && (
                              <pre className="p-2 rounded bg-gray-950 text-[10px] text-cyan-200/90 whitespace-pre-wrap max-h-40 overflow-y-auto leading-relaxed border border-gray-900">
                                {msg.executionResult.stdout}
                              </pre>
                            )}
                          </div>
                        )}
                        {msg.careInsight && (
                          <div className="mt-2 pt-2 border-t border-pink-900/40 text-[11px] text-pink-300 italic flex items-center gap-1">
                            <Heart className="w-3.5 h-3.5 text-pink-400 shrink-0" />
                            <span>{msg.careInsight}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
                {isProcessing && (
                  <div className="flex items-center gap-2 text-cyan-400 text-xs py-2">
                    <span className="animate-spin font-bold">⠋</span>
                    <span>Priya is orchestrating launch automation &amp; system commands...</span>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Chat Input Bar */}
              <div className="p-3 bg-gray-900/90 border-t border-cyan-900/40 flex items-center gap-2">
                <button
                  onClick={toggleSpeechRecognition}
                  className={`p-2 rounded-xl transition-all ${
                    isListening
                      ? 'bg-red-600 text-white animate-pulse'
                      : 'bg-gray-800 text-gray-300 hover:text-cyan-300 border border-gray-700'
                  }`}
                  title={isListening ? 'Listening...' : 'Push to talk with Priya'}
                >
                  {isListening ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
                </button>
                <input
                  type="text"
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                  placeholder={`Speak or type order (e.g. "Priya, run test_launch.py and check Playwright")...`}
                  className="flex-1 bg-gray-950 border border-cyan-900/50 rounded-xl px-3.5 py-2 text-xs text-gray-100 placeholder-gray-500 focus:outline-none focus:border-cyan-400 font-mono"
                  disabled={isProcessing}
                />
                <button
                  onClick={() => handleSendMessage()}
                  disabled={isProcessing || !inputMessage.trim()}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-pink-600 hover:from-cyan-500 hover:to-pink-500 disabled:opacity-40 text-black text-xs font-bold transition-all shadow-md flex items-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>DISPATCH</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Kali Terminal Deck */}
        {activeTab === 'terminal' && (
          <div className="h-[650px]">
            <KaliTerminal
              activeOsMode={osMode}
              onOsModeChange={(m) => setOsMode(m)}
              sudoEnabled={sudoEnabled}
              onToggleSudo={() => setSudoEnabled(!sudoEnabled)}
              onExecuteCommand={executeTerminalFromHUD}
              externalEntries={terminalEntries}
            />
          </div>
        )}

        {/* Kali Applications Deck */}
        {activeTab === 'apps' && (
          <div>
            <KaliAppLauncher
              onRunCommand={async (cmd, toolName) => {
                const res = await executeTerminalFromHUD(cmd);
                setTerminalEntries((prev) => [
                  ...prev,
                  {
                    id: `launcher-${Date.now()}`,
                    command: cmd,
                    output: res.stdout || '',
                    stderr: res.stderr,
                    exitCode: res.exitCode ?? 0,
                    timestamp: new Date().toLocaleTimeString(),
                    osMode,
                    isSudo: sudoEnabled,
                    priyaNote: `Directly launched from Kali Suite: ${toolName || cmd}`,
                  },
                ]);
                return res;
              }}
              onAskPriya={(prompt) => {
                setActiveTab('hud');
                handleSendMessage(prompt);
              }}
              osMode={osMode}
            />
          </div>
        )}

        {/* Mouse Control Deck */}
        {activeTab === 'mouse' && (
          <div>
            <MouseControlHUD
              onExecuteMouseAction={handleExecuteMouseAction}
              onAskPriya={(prompt) => {
                setActiveTab('hud');
                handleSendMessage(prompt);
              }}
              externalMouseState={mouseState}
            />
          </div>
        )}

        {/* Priya Care & Life Hub */}
        {activeTab === 'care' && (
          <div>
            <PriyaCareHub
              userName={userName}
              initialWater={waterIntake}
              initialPomodoro={pomodoroCount}
              initialPushups={pushupCount}
              onUpdateCare={(updates) => {
                if (updates.healthStats?.waterIntakeMl)
                  setWaterIntake(updates.healthStats.waterIntakeMl);
                if (updates.healthStats?.pushupsCount)
                  setPushupCount(updates.healthStats.pushupsCount);
              }}
            />
          </div>
        )}

        {/* Full Python Files & Zip Downloader */}
        {activeTab === 'explorer' && (
          <div>
            <MarkLviExplorer />
          </div>
        )}
      </main>

      {/* Multimodal Camera Vision Modal */}
      <CameraVisionModal
        isOpen={cameraModalOpen}
        onClose={() => setCameraModalOpen(false)}
        userName={userName}
      />
    </div>
  );
}
