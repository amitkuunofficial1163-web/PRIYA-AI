// Priya Speech Synthesis & Voice Controller with Emotion Tone Modulation
export interface SpeechOptions {
  pitch?: number;
  rate?: number;
  volume?: number;
  onViseme?: (mouthOpen: number) => void;
  onStart?: () => void;
  onEnd?: () => void;
}

class PriyaVoiceEngine {
  private synth: SpeechSynthesis | null = null;
  private selectedVoice: SpeechSynthesisVoice | null = null;
  private isSpeaking: boolean = false;
  private visemeTimer: any = null;

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.synth = window.speechSynthesis;
      this.loadVoices();
      if (this.synth.onvoiceschanged !== undefined) {
        this.synth.onvoiceschanged = () => this.loadVoices();
      }
    }
  }

  private loadVoices() {
    if (!this.synth) return;
    const voices = this.synth.getVoices();
    // Prefer natural, warm, melodic female English voices
    const preferred =
      voices.find(
        (v) =>
          (v.name.includes('Natural') ||
            v.name.includes('Google') ||
            v.name.includes('Samantha') ||
            v.name.includes('Zira') ||
            v.name.includes('Female')) &&
          v.lang.startsWith('en')
      ) ||
      voices.find((v) => v.lang.startsWith('en')) ||
      voices[0];

    this.selectedVoice = preferred || null;
  }

  public speak(text: string, emotion: string = 'caring', options?: SpeechOptions) {
    if (!this.synth) return;

    // Clean text of emotion tags or markdown if present
    const cleanText = text
      .replace(/\[EMOTION:[a-z]+\]/gi, '')
      .replace(/[*#`_]/g, '')
      .trim();

    if (!cleanText) return;

    this.synth.cancel(); // Stop previous utterance
    this.stopVisemeSimulation();

    const utterance = new SpeechSynthesisUtterance(cleanText);
    if (this.selectedVoice) {
      utterance.voice = this.selectedVoice;
    }

    // Emotion tone calibration
    let pitch = options?.pitch ?? 1.1;
    let rate = options?.rate ?? 1.0;

    switch (emotion) {
      case 'caring':
      case 'affectionate':
        pitch = 1.15;
        rate = 0.95;
        break;
      case 'protective':
      case 'focused':
        pitch = 1.0;
        rate = 1.08;
        break;
      case 'playful':
      case 'excited':
        pitch = 1.25;
        rate = 1.12;
        break;
      case 'calm':
        pitch = 1.05;
        rate = 0.9;
        break;
    }

    utterance.pitch = pitch;
    utterance.rate = rate;
    utterance.volume = options?.volume ?? 1.0;

    utterance.onstart = () => {
      this.isSpeaking = true;
      options?.onStart?.();
      this.startVisemeSimulation(options?.onViseme);
    };

    utterance.onend = () => {
      this.isSpeaking = false;
      this.stopVisemeSimulation();
      options?.onViseme?.(0);
      options?.onEnd?.();
    };

    utterance.onerror = () => {
      this.isSpeaking = false;
      this.stopVisemeSimulation();
      options?.onViseme?.(0);
      options?.onEnd?.();
    };

    this.synth.speak(utterance);
  }

  private startVisemeSimulation(onViseme?: (val: number) => void) {
    if (!onViseme) return;
    this.stopVisemeSimulation();
    this.visemeTimer = setInterval(() => {
      if (!this.isSpeaking) {
        onViseme(0);
        return;
      }
      const randomWave = 0.2 + Math.sin(Date.now() / 80) * 0.4 + Math.random() * 0.35;
      onViseme(Math.max(0.05, Math.min(1.0, randomWave)));
    }, 60);
  }

  private stopVisemeSimulation() {
    if (this.visemeTimer) {
      clearInterval(this.visemeTimer);
      this.visemeTimer = null;
    }
  }

  public cancel() {
    if (this.synth) {
      this.synth.cancel();
      this.isSpeaking = false;
      this.stopVisemeSimulation();
    }
  }

  public getSpeakingState(): boolean {
    return this.isSpeaking;
  }
}

export const priyaVoice = new PriyaVoiceEngine();
