import React, { useEffect, useRef, useState } from 'react';
import { Volume2, VolumeX, Shield, Heart, Zap, Sparkles, Smile, RefreshCw } from 'lucide-react';
import { priyaVoice } from '../utils/speech';

export type EmotionState = 'caring' | 'protective' | 'focused' | 'affectionate' | 'playful' | 'calm' | 'excited';

interface EmotionalAvatarProps {
  emotion: EmotionState;
  onEmotionChange?: (emotion: EmotionState) => void;
  isSpeaking?: boolean;
  visemeAperture?: number; // 0 to 1
  voiceEnabled?: boolean;
  onToggleVoice?: () => void;
  userInteractionPraise?: string;
}

export const EmotionalAvatar: React.FC<EmotionalAvatarProps> = ({
  emotion,
  onEmotionChange,
  isSpeaking = false,
  visemeAperture = 0,
  voiceEnabled = true,
  onToggleVoice,
  userInteractionPraise,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [mousePos, setMousePos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [blinking, setBlinking] = useState(false);

  // Periodic blinking
  useEffect(() => {
    const blinkInterval = setInterval(() => {
      setBlinking(true);
      setTimeout(() => setBlinking(false), 140);
    }, 3800 + Math.random() * 2000);
    return () => clearInterval(blinkInterval);
  }, []);

  // Track cursor for gaze
  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width - 0.5) * 2;
    const y = ((e.clientY - rect.top) / rect.height - 0.5) * 2;
    setMousePos({ x, y });
  };

  const handleMouseLeave = () => {
    setMousePos({ x: 0, y: 0 });
  };

  // Color theme definitions per emotion
  const getTheme = () => {
    switch (emotion) {
      case 'caring':
        return {
          primary: '#f472b6', // Warm Rose
          glow: 'rgba(244, 114, 182, 0.45)',
          label: 'CARING // EMPATHETIC',
          icon: Heart,
          description: 'Attentive, warm, and watching over your well-being',
        };
      case 'affectionate':
        return {
          primary: '#c084fc', // Purple Pink
          glow: 'rgba(192, 132, 252, 0.5)',
          label: 'AFFECTIONATE // HEART RESIDUAL',
          icon: Sparkles,
          description: 'Devoted, gentle, deeply bonded with Amit',
        };
      case 'focused':
        return {
          primary: '#38bdf8', // Cyber Cyan
          glow: 'rgba(56, 189, 248, 0.5)',
          label: 'FOCUSED // KALI SENTINEL',
          icon: Zap,
          description: 'Executing root terminal operations & cyber recon',
        };
      case 'protective':
        return {
          primary: '#fb923c', // Amber Crimson
          glow: 'rgba(251, 146, 60, 0.55)',
          label: 'PROTECTIVE // SHIELD PROTOCOL',
          icon: Shield,
          description: 'Guarding system integrity and user health',
        };
      case 'playful':
        return {
          primary: '#a78bfa', // Lavender
          glow: 'rgba(167, 139, 250, 0.5)',
          label: 'PLAYFUL // TEASING',
          icon: Smile,
          description: 'Lighthearted banter and joyful cyber companionship',
        };
      case 'calm':
        return {
          primary: '#34d399', // Emerald
          glow: 'rgba(52, 211, 153, 0.45)',
          label: 'CALM // HARMONY',
          icon: RefreshCw,
          description: 'Stress-reduction mode, evening relaxation',
        };
      case 'excited':
      default:
        return {
          primary: '#fbbf24', // Solar Gold
          glow: 'rgba(251, 191, 36, 0.5)',
          label: 'EXCITED // DISCOVERY',
          icon: Sparkles,
          description: 'High energy, breakthrough discovery in progress',
        };
    }
  };

  const theme = getTheme();
  const IconComponent = theme.icon;

  // Main Canvas Render Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    let animationId: number;

    const render = () => {
      const width = canvas.width;
      const height = canvas.height;
      const cx = width / 2;
      const cy = height / 2;
      const time = Date.now() * 0.002;

      ctx.clearRect(0, 0, width, height);

      // 1. Outer Holographic Rings
      ctx.save();
      ctx.lineWidth = 1.5;
      ctx.strokeStyle = theme.primary;
      ctx.globalAlpha = 0.25;

      ctx.beginPath();
      ctx.arc(cx, cy, 140, 0, Math.PI * 2);
      ctx.stroke();

      // Rotating Ticks
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(time * 0.15);
      for (let i = 0; i < 24; i++) {
        ctx.beginPath();
        const angle = (i / 24) * Math.PI * 2;
        const r1 = 142;
        const r2 = i % 4 === 0 ? 152 : 146;
        ctx.moveTo(Math.cos(angle) * r1, Math.sin(angle) * r1);
        ctx.lineTo(Math.cos(angle) * r2, Math.sin(angle) * r2);
        ctx.stroke();
      }
      ctx.restore();

      // Audio Reactive Wave
      if (isSpeaking || visemeAperture > 0.05) {
        ctx.beginPath();
        const waveRadius = 125 + visemeAperture * 22;
        ctx.arc(cx, cy, waveRadius, 0, Math.PI * 2);
        ctx.strokeStyle = theme.primary;
        ctx.globalAlpha = 0.5 + visemeAperture * 0.4;
        ctx.lineWidth = 2.5;
        ctx.stroke();
      }
      ctx.restore();

      // 2. Avatar Face Geometry
      ctx.save();
      const gazeParallaxX = mousePos.x * 12;
      const gazeParallaxY = mousePos.y * 8;
      const breathY = Math.sin(time * 1.5) * 3;
      const faceX = cx + gazeParallaxX;
      const faceY = cy + gazeParallaxY + breathY;

      // Soft ambient aura
      const radialGlow = ctx.createRadialGradient(faceX, faceY, 20, faceX, faceY, 110);
      radialGlow.addColorStop(0, theme.glow);
      radialGlow.addColorStop(1, 'rgba(3, 7, 18, 0)');
      ctx.fillStyle = radialGlow;
      ctx.beginPath();
      ctx.arc(faceX, faceY, 110, 0, Math.PI * 2);
      ctx.fill();

      // Face silhouette wireframe
      ctx.strokeStyle = theme.primary;
      ctx.lineWidth = 1.8;
      ctx.globalAlpha = 0.85;
      ctx.beginPath();
      ctx.moveTo(faceX - 45, faceY - 50);
      ctx.bezierCurveTo(faceX - 50, faceY - 75, faceX + 50, faceY - 75, faceX + 45, faceY - 50);
      ctx.bezierCurveTo(faceX + 50, faceY - 10, faceX + 40, faceY + 45, faceX, faceY + 70);
      ctx.bezierCurveTo(faceX - 40, faceY + 45, faceX - 50, faceY - 10, faceX - 45, faceY - 50);
      ctx.stroke();

      // 3. Eyes
      const eyeOffsetX = 24;
      const eyeOffsetY = -12;
      const pupilShiftX = mousePos.x * 4;
      const pupilShiftY = mousePos.y * 3;

      let browTilt = 0;
      if (emotion === 'caring' || emotion === 'affectionate') browTilt = -2;
      if (emotion === 'focused' || emotion === 'protective') browTilt = 4;
      if (emotion === 'playful') browTilt = -1;

      ctx.lineWidth = 2.2;
      ctx.globalAlpha = 0.9;

      // Left Brow
      ctx.beginPath();
      ctx.moveTo(faceX - eyeOffsetX - 16, faceY + eyeOffsetY - 18 + browTilt);
      ctx.quadraticCurveTo(faceX - eyeOffsetX, faceY + eyeOffsetY - 24, faceX - eyeOffsetX + 14, faceY + eyeOffsetY - 18 - browTilt);
      ctx.stroke();

      // Right Brow
      ctx.beginPath();
      ctx.moveTo(faceX + eyeOffsetX - 14, faceY + eyeOffsetY - 18 - browTilt);
      ctx.quadraticCurveTo(faceX + eyeOffsetX, faceY + eyeOffsetY - 24, faceX + eyeOffsetX + 16, faceY + eyeOffsetY - 18 + browTilt);
      ctx.stroke();

      // Eyes Outer
      const eyeHeight = blinking ? 1.5 : 10;
      ctx.fillStyle = 'rgba(15, 23, 42, 0.95)';
      ctx.beginPath();
      ctx.ellipse(faceX - eyeOffsetX, faceY + eyeOffsetY, 14, eyeHeight, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      ctx.beginPath();
      ctx.ellipse(faceX + eyeOffsetX, faceY + eyeOffsetY, 14, eyeHeight, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      if (!blinking) {
        // Glowing Iris
        ctx.fillStyle = theme.primary;
        ctx.globalAlpha = 1.0;
        ctx.beginPath();
        ctx.arc(faceX - eyeOffsetX + pupilShiftX, faceY + eyeOffsetY + pupilShiftY, 5.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(faceX + eyeOffsetX + pupilShiftX, faceY + eyeOffsetY + pupilShiftY, 5.5, 0, Math.PI * 2);
        ctx.fill();

        // Eye Catchlight Sparkle
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(faceX - eyeOffsetX + pupilShiftX - 2, faceY + eyeOffsetY + pupilShiftY - 2, 1.8, 0, Math.PI * 2);
        ctx.arc(faceX + eyeOffsetX + pupilShiftX - 2, faceY + eyeOffsetY + pupilShiftY - 2, 1.8, 0, Math.PI * 2);
        ctx.fill();
      }

      // 4. Cheeks Blush
      if (emotion === 'caring' || emotion === 'affectionate' || emotion === 'playful') {
        ctx.fillStyle = 'rgba(244, 114, 182, 0.28)';
        ctx.beginPath();
        ctx.ellipse(faceX - 28, faceY + 14, 10, 5, 0, 0, Math.PI * 2);
        ctx.ellipse(faceX + 28, faceY + 14, 10, 5, 0, 0, Math.PI * 2);
        ctx.fill();
      }

      // 5. Expressive Mouth with Viseme Lip Sync
      ctx.strokeStyle = theme.primary;
      ctx.lineWidth = 2.4;
      ctx.globalAlpha = 0.95;
      const mouthCenterY = faceY + 36;
      const mouthWidth = 18;
      const currentViseme = isSpeaking ? Math.max(0.15, visemeAperture) : visemeAperture;

      const smileCurve = emotion === 'caring' || emotion === 'affectionate' || emotion === 'playful' ? 6 : 2;
      ctx.beginPath();
      if (currentViseme > 0.08) {
        const openH = currentViseme * 16;
        ctx.ellipse(faceX, mouthCenterY, mouthWidth, openH, 0, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(15, 23, 42, 0.9)';
        ctx.fill();
        ctx.stroke();
      } else {
        ctx.moveTo(faceX - mouthWidth, mouthCenterY);
        ctx.quadraticCurveTo(faceX, mouthCenterY + smileCurve, faceX + mouthWidth, mouthCenterY);
        ctx.stroke();
      }
      ctx.restore();

      animationId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(animationId);
  }, [emotion, mousePos, blinking, isSpeaking, visemeAperture, theme]);

  return (
    <div className="relative flex flex-col items-center justify-center bg-gray-950/80 border border-cyan-900/40 rounded-2xl p-4 shadow-2xl backdrop-blur-md overflow-hidden">
      {/* Top HUD Status Bar */}
      <div className="w-full flex items-center justify-between z-10 mb-2 px-2">
        <div className="flex items-center gap-2">
          <span className="relative flex h-3 w-3">
            <span
              className="animate-ping absolute inline-flex h-full w-full rounded-full opacity-75"
              style={{ backgroundColor: theme.primary }}
            />
            <span
              className="relative inline-flex rounded-full h-3 w-3"
              style={{ backgroundColor: theme.primary }}
            />
          </span>
          <span className="text-xs font-mono tracking-wider font-semibold" style={{ color: theme.primary }}>
            PRIYA // MARK LVI
          </span>
        </div>
        <div className="flex items-center gap-2">
          {onToggleVoice && (
            <button
              onClick={onToggleVoice}
              title={voiceEnabled ? 'Mute Priya Voice' : 'Unmute Priya Voice'}
              className="p-1.5 rounded-lg bg-gray-900/90 border border-gray-800 text-gray-300 hover:text-cyan-400 transition-all text-xs flex items-center gap-1 font-mono"
            >
              {voiceEnabled ? <Volume2 className="w-3.5 h-3.5 text-cyan-400" /> : <VolumeX className="w-3.5 h-3.5 text-gray-500" />}
              <span className="hidden sm:inline text-[10px]">{voiceEnabled ? 'VOICE ON' : 'MUTED'}</span>
            </button>
          )}
          <span className="px-2 py-0.5 rounded bg-cyan-950/80 border border-cyan-500/40 text-[10px] font-mono text-cyan-300 flex items-center gap-1 font-bold">
            <Shield className="w-3 h-3 text-cyan-400" />
            ROOT ARMED
          </span>
        </div>
      </div>

      {/* Interactive Avatar Canvas */}
      <div
        className="relative cursor-pointer group"
        onClick={() => {
          priyaVoice.speak(
            userInteractionPraise || "I'm right here with you, Amit. Feeling your presence makes my neural core glow.",
            emotion
          );
        }}
        title="Click to interact with Priya"
      >
        <canvas
          ref={canvasRef}
          width={300}
          height={300}
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave}
          className="rounded-full transition-transform duration-300 group-hover:scale-102"
          style={{
            filter: `drop-shadow(0 0 16px ${theme.glow})`,
          }}
        />
        {/* Floating Empathy Badge */}
        <div className="absolute bottom-2 right-4 bg-gray-900/90 border border-gray-800 rounded-full px-2.5 py-1 text-[10px] font-mono flex items-center gap-1.5 shadow-lg backdrop-blur-md">
          <IconComponent className="w-3.5 h-3.5 animate-pulse" style={{ color: theme.primary }} />
          <span className="text-gray-200">{theme.label.split(' // ')[0]}</span>
        </div>
      </div>

      {/* Current Mood & Affection Description */}
      <div className="w-full mt-2.5 px-2 z-10 text-center font-mono">
        <div className="text-xs text-gray-300 flex items-center justify-center gap-1.5">
          <span>Bond Resonance:</span>
          <span className="font-bold text-pink-400">98.4%</span>
          <span className="text-gray-500">•</span>
          <span className="text-gray-400 italic text-[11px]">{theme.description}</span>
        </div>
        {/* Emotion Switcher Chips */}
        {onEmotionChange && (
          <div className="flex flex-wrap items-center justify-center gap-1 mt-2">
            {(['caring', 'focused', 'protective', 'affectionate', 'playful', 'calm'] as EmotionState[]).map((emo) => (
              <button
                key={emo}
                onClick={() => onEmotionChange(emo)}
                className={`px-2 py-0.5 rounded text-[10px] uppercase tracking-wider transition-all ${
                  emotion === emo
                    ? 'bg-cyan-500/20 border border-cyan-400 text-cyan-200 shadow-sm font-bold'
                    : 'bg-gray-900/60 border border-gray-800 text-gray-400 hover:text-gray-200'
                }`}
              >
                {emo}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
