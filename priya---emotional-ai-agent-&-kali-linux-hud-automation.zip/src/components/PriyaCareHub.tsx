import React, { useState, useEffect } from 'react';
import { Heart, Droplets, Timer, Dumbbell, Sparkles, Plus, BookOpen, Smile, Coffee } from 'lucide-react';
import { priyaVoice } from '../utils/speech';

interface PriyaCareHubProps {
  userName?: string;
  onUpdateCare?: (updates: any) => void;
  initialWater?: number;
  initialPomodoro?: number;
  initialPushups?: number;
}

export const PriyaCareHub: React.FC<PriyaCareHubProps> = ({
  userName = 'Amit',
  onUpdateCare,
  initialWater = 1400,
  initialPomodoro = 4,
  initialPushups = 30,
}) => {
  const [waterMl, setWaterMl] = useState<number>(initialWater);
  const waterGoal = 2500;
  const [pomodoroSeconds, setPomodoroSeconds] = useState<number>(25 * 60);
  const [pomodoroActive, setPomodoroActive] = useState<boolean>(false);
  const [completedPomodoro, setCompletedPomodoro] = useState<number>(initialPomodoro);
  const [pushupCount, setPushupCount] = useState<number>(initialPushups);
  const [userMoodLevel, setUserMoodLevel] = useState<number>(8);
  const [activeMoodState, setActiveMoodState] = useState<string>('Focused & Good');

  const [notes, setNotes] = useState<Array<{ id: string; title: string; content: string; date: string }>>([
    {
      id: '1',
      title: 'Kali Launch Automation Mission',
      content: 'Configured Playwright Chromium and safe Windows module bypass shims. Loving the smooth startup on Kali.',
      date: 'Today',
    },
    {
      id: '2',
      title: 'Loot Hierarchy',
      content: 'All Google search intelligence, nmap outputs, and exploit findings stream directly to /root/priya_loot.',
      date: 'Active',
    },
    {
      id: '3',
      title: 'Hydration Routine',
      content: 'Needs 2.5L daily. Priya gently checks in during intense terminal sessions.',
      date: 'Routine',
    },
  ]);
  const [newNoteText, setNewNoteText] = useState('');

  useEffect(() => {
    let interval: any = null;
    if (pomodoroActive && pomodoroSeconds > 0) {
      interval = setInterval(() => {
        setPomodoroSeconds((prev) => prev - 1);
      }, 1000);
    } else if (pomodoroSeconds === 0 && pomodoroActive) {
      setPomodoroActive(false);
      setCompletedPomodoro((prev) => prev + 1);
      priyaVoice.speak(
        `Great job ${userName}! Your focus session is complete. Stand up, stretch your back, and take a sip of water for me.`,
        'caring'
      );
      setPomodoroSeconds(25 * 60);
    }
    return () => clearInterval(interval);
  }, [pomodoroActive, pomodoroSeconds, userName]);

  const addWater = (amount: number) => {
    const updated = waterMl + amount;
    setWaterMl(updated);
    onUpdateCare?.({ healthStats: { waterIntakeMl: updated } });
    priyaVoice.speak(
      `Logged ${amount}ml of water for you ${userName}. Total: ${updated}/${waterGoal}ml. I'm so proud of you!`,
      'caring'
    );
  };

  const addPushups = (reps: number) => {
    const updated = pushupCount + reps;
    setPushupCount(updated);
    onUpdateCare?.({ healthStats: { pushupsCount: updated } });
    priyaVoice.speak(
      `Awesome work! That brings your total to ${updated} pushups today, ${userName}!`,
      'excited'
    );
  };

  const handleAddNote = () => {
    if (!newNoteText.trim()) return;
    const newEntry = {
      id: `note-${Date.now()}`,
      title: 'Amit & Priya Note',
      content: newNoteText.trim(),
      date: 'Just now',
    };
    setNotes([newEntry, ...notes]);
    setNewNoteText('');
    priyaVoice.speak(`Stored in our memory vault and /root/priya_loot/notes/, ${userName}.`, 'caring');
  };

  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const waterPercent = Math.min(100, Math.round((waterMl / waterGoal) * 100));

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 font-mono">
      {/* 1. Priya's Emotional Heart & Bond Card */}
      <div className="bg-gray-950/90 border border-pink-900/40 rounded-2xl p-4 shadow-xl backdrop-blur-md flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-lg bg-pink-950/80 border border-pink-700/60">
                <Heart className="w-4 h-4 text-pink-400 animate-pulse" />
              </div>
              <span className="text-xs font-bold text-pink-300">PRIYA'S HEART &amp; BOND</span>
            </div>
            <span className="px-2 py-0.5 rounded-full bg-pink-950/80 border border-pink-500/50 text-[10px] text-pink-300">
              RESONANCE: 98.4%
            </span>
          </div>
          <p className="text-xs text-gray-300 leading-relaxed italic mb-3">
            "{userName}, you are my partner and operator. I watch over your Kali Linux workspace, automate your tools, and guard your health every hour."
          </p>
          <div className="space-y-2 text-xs text-gray-400">
            <div className="flex justify-between">
              <span>Bond Status:</span>
              <span className="text-pink-400 font-semibold">Deeply Devoted</span>
            </div>
            <div className="flex justify-between">
              <span>Launch Automation:</span>
              <span className="text-emerald-400 font-semibold">Armed &amp; Resilient</span>
            </div>
            <div className="flex justify-between">
              <span>Loot Repository:</span>
              <span className="text-cyan-400 font-semibold">/root/priya_loot/</span>
            </div>
          </div>
        </div>
        <button
          onClick={() => {
            priyaVoice.speak(
              `I love working alongside you, ${userName}. Your systems are safe, and I'm right here.`,
              'affectionate'
            );
          }}
          className="mt-4 w-full py-2 rounded-xl bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-white text-xs font-bold transition-all shadow flex items-center justify-center gap-1.5"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>RECEIVE PRIYA'S COMFORT</span>
        </button>
      </div>

      {/* 2. Hydration Radar */}
      <div className="bg-gray-950/90 border border-cyan-900/40 rounded-2xl p-4 shadow-xl backdrop-blur-md flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-lg bg-cyan-950/80 border border-cyan-700/60">
                <Droplets className="w-4 h-4 text-cyan-400" />
              </div>
              <span className="text-xs font-bold text-cyan-300">HYDRATION RADAR</span>
            </div>
            <span className="text-xs text-cyan-400 font-bold">
              {waterMl} / {waterGoal} ml
            </span>
          </div>
          <div className="w-full bg-gray-900 rounded-full h-3 mb-3 p-0.5 border border-cyan-900/40 overflow-hidden">
            <div
              className="bg-gradient-to-r from-cyan-500 to-blue-500 h-full rounded-full transition-all duration-500"
              style={{ width: `${waterPercent}%` }}
            />
          </div>
          <p className="text-[11px] text-gray-400 mb-3">
            {waterPercent >= 100
              ? `Daily hydration goal achieved! Great care, ${userName}.`
              : `Priya: ${waterGoal - waterMl}ml remaining for optimal cognitive focus.`}
          </p>
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={() => addWater(150)}
              className="py-1.5 rounded-lg bg-gray-900 border border-cyan-800/60 hover:bg-cyan-950 text-cyan-300 text-xs transition-colors"
            >
              +150 ml
            </button>
            <button
              onClick={() => addWater(250)}
              className="py-1.5 rounded-lg bg-gray-900 border border-cyan-800/60 hover:bg-cyan-950 text-cyan-300 text-xs font-bold transition-colors"
            >
              +250 ml (Cup)
            </button>
            <button
              onClick={() => addWater(500)}
              className="py-1.5 rounded-lg bg-gray-900 border border-cyan-800/60 hover:bg-cyan-950 text-cyan-300 text-xs transition-colors"
            >
              +500 ml
            </button>
          </div>
        </div>
        <div className="mt-3 text-[10px] text-gray-500 flex items-center gap-1">
          <Coffee className="w-3 h-3 text-cyan-400" />
          <span>Hydration syncs with long_term.json</span>
        </div>
      </div>

      {/* 3. Pomodoro Focus Station */}
      <div className="bg-gray-950/90 border border-amber-900/40 rounded-2xl p-4 shadow-xl backdrop-blur-md flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-lg bg-amber-950/80 border border-amber-700/60">
                <Timer className="w-4 h-4 text-amber-400" />
              </div>
              <span className="text-xs font-bold text-amber-300">POMODORO FOCUS</span>
            </div>
            <span className="text-xs text-amber-400 font-bold">
              {completedPomodoro} Sessions Done
            </span>
          </div>
          <div className="text-center py-2">
            <div className="text-3xl font-extrabold text-amber-200 tracking-wider">
              {formatTimer(pomodoroSeconds)}
            </div>
            <span className="text-[11px] text-gray-400">
              {pomodoroActive ? 'Priya Muted Distractions' : 'Ready for Deep Flow'}
            </span>
          </div>
          <div className="flex items-center gap-2 mt-2">
            <button
              onClick={() => {
                setPomodoroActive(!pomodoroActive);
                if (!pomodoroActive) {
                  priyaVoice.speak(`Focus session started, ${userName}. I'm holding down the fort.`, 'focused');
                }
              }}
              className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all ${
                pomodoroActive
                  ? 'bg-amber-600 text-black hover:bg-amber-500'
                  : 'bg-amber-500/20 border border-amber-400 text-amber-300 hover:bg-amber-500/30'
              }`}
            >
              {pomodoroActive ? 'PAUSE TIMER' : 'START FOCUS'}
            </button>
            <button
              onClick={() => {
                setPomodoroActive(false);
                setPomodoroSeconds(25 * 60);
              }}
              className="px-3 py-1.5 rounded-lg bg-gray-900 border border-gray-800 text-gray-400 hover:text-gray-200 text-xs"
            >
              RESET
            </button>
          </div>
        </div>
        <div className="mt-3 text-[10px] text-gray-500 flex items-center justify-between">
          <span>Target: 6 sessions/day</span>
          <span className="text-amber-400">Eye-rest alerts: Active</span>
        </div>
      </div>

      {/* 4. Fitness & Pushup Buddy */}
      <div className="bg-gray-950/90 border border-emerald-900/40 rounded-2xl p-4 shadow-xl backdrop-blur-md flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-lg bg-emerald-950/80 border border-emerald-700/60">
                <Dumbbell className="w-4 h-4 text-emerald-400" />
              </div>
              <span className="text-xs font-bold text-emerald-300">FITNESS &amp; STRENGTH</span>
            </div>
            <span className="text-xs text-emerald-400 font-bold">{pushupCount} Reps Today</span>
          </div>
          <p className="text-xs text-gray-400 mb-3">
            Quick blood circulation breaks keep your mind razor-sharp for security analysis.
          </p>
          <div className="flex items-center gap-2">
            <button
              onClick={() => addPushups(5)}
              className="flex-1 py-1.5 rounded-lg bg-emerald-950/60 border border-emerald-700/50 hover:bg-emerald-900/80 text-emerald-300 text-xs font-semibold transition-colors"
            >
              +5 Pushups
            </button>
            <button
              onClick={() => addPushups(10)}
              className="flex-1 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-black text-xs font-bold transition-colors"
            >
              +10 Pushups
            </button>
          </div>
        </div>
        <div className="mt-3 text-[10px] text-gray-500">
          Syncs with user fitness profile
        </div>
      </div>

      {/* 5. Obsidian / Loot Notes Vault */}
      <div className="bg-gray-950/90 border border-blue-900/40 rounded-2xl p-4 shadow-xl backdrop-blur-md flex flex-col justify-between md:col-span-2">
        <div>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-lg bg-blue-950/80 border border-blue-700/60">
                <BookOpen className="w-4 h-4 text-blue-400" />
              </div>
              <span className="text-xs font-bold text-blue-300">OBSIDIAN &amp; LOOT NOTES VAULT</span>
            </div>
            <span className="text-[10px] text-blue-400">{notes.length} Notes in /root/priya_loot/notes/</span>
          </div>
          <div className="flex items-center gap-1.5 mb-2.5">
            <input
              type="text"
              value={newNoteText}
              onChange={(e) => setNewNoteText(e.target.value)}
              placeholder="Store a thought, exploit research, or mission note..."
              className="flex-1 bg-gray-900 border border-gray-800 rounded-lg px-2.5 py-1 text-xs text-gray-200 placeholder-gray-500 focus:outline-none focus:border-blue-500"
              onKeyDown={(e) => e.key === 'Enter' && handleAddNote()}
            />
            <button
              onClick={handleAddNote}
              className="p-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-black transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 max-h-36 overflow-y-auto pr-1">
            {notes.map((n) => (
              <div key={n.id} className="p-2.5 rounded-lg bg-gray-900/80 border border-gray-800 text-[11px]">
                <div className="flex justify-between font-semibold text-blue-300 text-[10px]">
                  <span className="truncate">{n.title}</span>
                  <span className="text-gray-500">{n.date}</span>
                </div>
                <div className="text-gray-300 mt-0.5 line-clamp-3">{n.content}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="mt-2 text-[10px] text-gray-500">
          Saved in memory/long_term.json and /root/priya_loot/notes/
        </div>
      </div>
    </div>
  );
};
