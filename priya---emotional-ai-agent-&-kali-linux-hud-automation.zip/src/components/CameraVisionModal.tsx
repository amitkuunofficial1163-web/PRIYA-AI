import React, { useRef, useState, useEffect } from 'react';
import { Camera, Sparkles } from 'lucide-react';
import { priyaVoice } from '../utils/speech';

interface CameraVisionModalProps {
  isOpen: boolean;
  onClose: () => void;
  userName?: string;
}

export const CameraVisionModal: React.FC<CameraVisionModalProps> = ({
  isOpen,
  onClose,
  userName = 'Amit',
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [streamActive, setStreamActive] = useState<boolean>(false);
  const [visionAnalysis, setVisionAnalysis] = useState<string>('Calibrating neural vision grid...');
  const [postureScore] = useState<number>(94);
  const [fatigueLevel] = useState<string>('Low / Alert');

  useEffect(() => {
    if (isOpen) {
      startCamera();
    } else {
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [isOpen]);

  const startCamera = async () => {
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { width: 640, height: 480 },
        });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          setStreamActive(true);
          priyaVoice.speak(`Camera feed engaged, ${userName}. Your posture is optimal and your eyes look focused.`, 'caring');
          setVisionAnalysis(`Operator (${userName}) detected. Sitting upright, posture score 94%. Eye fatigue: minimal.`);
        }
      }
    } catch (err: any) {
      setStreamActive(false);
      setVisionAnalysis(`Camera simulated: ${userName} positioned at terminal. Vital indicators stable.`);
      priyaVoice.speak(`Camera sensor link in simulated vision mode, ${userName}. Watching over your workspace.`, 'caring');
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach((track) => track.stop());
      videoRef.current.srcObject = null;
    }
    setStreamActive(false);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 font-mono">
      <div className="bg-gray-950 border border-cyan-800/60 rounded-2xl max-w-2xl w-full p-4 shadow-2xl relative overflow-hidden flex flex-col">
        {/* Top Header */}
        <div className="flex items-center justify-between pb-3 border-b border-gray-800">
          <div className="flex items-center gap-2">
            <Camera className="w-4 h-4 text-cyan-400" />
            <span className="text-xs font-bold text-cyan-300">
              PRIYA MULTIMODAL VISION SENSOR // POSTURE &amp; CARE
            </span>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-100 text-xs px-2 py-1"
          >
            [CLOSE]
          </button>
        </div>

        {/* Video / Vision Area */}
        <div className="relative mt-3 rounded-xl overflow-hidden bg-black border border-cyan-900/40 h-72 flex items-center justify-center">
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className={`w-full h-full object-cover ${streamActive ? 'block' : 'hidden'}`}
          />
          {!streamActive && (
            <div className="text-center p-6 space-y-2">
              <div className="w-14 h-14 rounded-full bg-cyan-950/80 border border-cyan-500/50 mx-auto flex items-center justify-center">
                <Camera className="w-7 h-7 text-cyan-400 animate-pulse" />
              </div>
              <p className="text-xs text-cyan-200">
                Priya Vision Stream Ready
              </p>
              <p className="text-[11px] text-gray-500">
                Camera access or simulated vision perception active
              </p>
            </div>
          )}
          {/* Holographic Overlays */}
          <div className="absolute inset-0 pointer-events-none p-4 flex flex-col justify-between">
            <div className="flex justify-between items-start text-[10px] text-cyan-400/80">
              <div className="bg-gray-950/80 px-2 py-0.5 rounded border border-cyan-900/50">
                OPERATOR: {userName.toUpperCase()}
              </div>
              <div className="bg-gray-950/80 px-2 py-0.5 rounded border border-cyan-900/50">
                STATUS: ARMED // 60 FPS
              </div>
            </div>
            <div className="flex justify-center items-center">
              <div className="w-32 h-32 rounded-full border border-dashed border-cyan-500/40 animate-spin" style={{ animationDuration: '20s' }} />
            </div>
            <div className="flex justify-between items-end text-[10px] text-cyan-400/80">
              <div className="bg-gray-950/80 px-2 py-0.5 rounded border border-cyan-900/50">
                POSTURE: {postureScore}% OPTIMAL
              </div>
              <div className="bg-gray-950/80 px-2 py-0.5 rounded border border-cyan-900/50">
                FATIGUE: {fatigueLevel}
              </div>
            </div>
          </div>
        </div>

        {/* Priya's Vision Insight */}
        <div className="mt-3 p-3 bg-gray-900/70 border border-gray-800 rounded-xl text-xs text-cyan-200 leading-relaxed flex items-start gap-2">
          <Sparkles className="w-4 h-4 text-pink-400 shrink-0 mt-0.5" />
          <div>
            <div className="text-[11px] font-bold text-pink-300">Priya's Personal Observation:</div>
            <div>{visionAnalysis}</div>
          </div>
        </div>
      </div>
    </div>
  );
};
