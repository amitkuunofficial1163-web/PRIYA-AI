import React, { useState } from 'react';
import { FolderTree, FileCode, Download, Copy, Check, Search, ExternalLink, Sparkles } from 'lucide-react';
import { MARK_LVI_FILES, MarkLviFile } from '../data/markLviFiles';
import JSZip from 'jszip';

export const MarkLviExplorer: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<MarkLviFile>(MARK_LVI_FILES[0]);
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [copied, setCopied] = useState(false);
  const [isExporting, setIsExporting] = useState(false);

  const categories = [
    { id: 'all', label: 'All Files' },
    { id: 'root', label: 'Root Launch Scripts' },
    { id: 'core', label: 'Core & Shims' },
    { id: 'actions', label: 'Playwright & Tools' },
    { id: 'memory', label: 'Memory & Long Term' },
    { id: 'config', label: 'Config & Keys' },
  ];

  const filteredFiles = MARK_LVI_FILES.filter((file) => {
    const matchesCategory = categoryFilter === 'all' || file.category === categoryFilter;
    const matchesSearch =
      file.path.toLowerCase().includes(searchQuery.toLowerCase()) ||
      file.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadZip = async () => {
    setIsExporting(true);
    try {
      const zip = new JSZip();
      const rootFolder = zip.folder('Priya---emotional-ai-agent-&-kali_windows-mark-lvi-hud');
      for (const file of MARK_LVI_FILES) {
        rootFolder?.file(file.path, file.content);
      }
      const content = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'Priya---emotional-ai-agent-&-kali_windows-mark-lvi-hud.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Failed to create zip:', err);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="bg-gray-950/90 border border-cyan-900/40 rounded-2xl p-4 shadow-2xl backdrop-blur-md flex flex-col h-[650px] font-mono">
      {/* Header Bar */}
      <div className="flex flex-wrap items-center justify-between pb-3 border-b border-gray-800 gap-2">
        <div className="flex items-center gap-2">
          <FolderTree className="w-4 h-4 text-cyan-400" />
          <span className="text-xs font-bold text-cyan-300">
            PYTHON PROJECT REPOSITORY EXPLORER
          </span>
          <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800">
            {MARK_LVI_FILES.length} Files
          </span>
        </div>
        <button
          onClick={handleDownloadZip}
          disabled={isExporting}
          className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-black text-xs font-bold flex items-center gap-1.5 transition-all shadow-md disabled:opacity-50"
        >
          <Download className="w-3.5 h-3.5" />
          <span>{isExporting ? 'PACKAGING ZIP...' : 'DOWNLOAD FULL REPO (.ZIP)'}</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 py-2.5 border-b border-gray-900">
        <div className="flex items-center gap-1.5 overflow-x-auto text-[11px]">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setCategoryFilter(cat.id)}
              className={`px-2 py-0.5 rounded-md transition-all shrink-0 ${
                categoryFilter === cat.id
                  ? 'bg-cyan-500/20 border border-cyan-400 text-cyan-200 font-semibold'
                  : 'bg-gray-900/60 border border-gray-800 text-gray-400 hover:text-gray-200'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
        <div className="relative">
          <Search className="w-3.5 h-3.5 text-gray-500 absolute left-2.5 top-2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search Python files..."
            className="pl-8 pr-3 py-1 bg-gray-900 border border-gray-800 rounded-lg text-xs text-gray-200 placeholder-gray-500 focus:outline-none focus:border-cyan-500"
          />
        </div>
      </div>

      {/* Split: File Tree on left, Code Viewer on right */}
      <div className="flex-1 grid grid-cols-1 md:grid-cols-12 gap-3 mt-3 overflow-hidden">
        {/* Left: File Tree List */}
        <div className="md:col-span-4 bg-gray-900/60 border border-gray-800/80 rounded-xl overflow-y-auto p-2 space-y-1">
          {filteredFiles.map((file) => {
            const isSelected = selectedFile.path === file.path;
            return (
              <button
                key={file.path}
                onClick={() => setSelectedFile(file)}
                className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs transition-all flex flex-col ${
                  isSelected
                    ? 'bg-cyan-950/80 border border-cyan-500/50 text-cyan-200 font-bold'
                    : 'text-gray-400 hover:bg-gray-800/60 hover:text-gray-200 border border-transparent'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 truncate">
                    <FileCode className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-cyan-400' : 'text-gray-500'}`} />
                    <span className="truncate">{file.name}</span>
                  </div>
                  {file.isNewOrUpdated && (
                    <span className="text-[9px] px-1 py-0.2 rounded bg-amber-950 text-amber-300 border border-amber-800 font-semibold shrink-0">
                      UPDATED
                    </span>
                  )}
                </div>
                <span className="text-[10px] text-gray-500 truncate pl-5">{file.path}</span>
              </button>
            );
          })}
        </div>

        {/* Right: Code Viewer */}
        <div className="md:col-span-8 flex flex-col bg-gray-900/40 border border-gray-800/80 rounded-xl overflow-hidden">
          <div className="flex items-center justify-between px-3 py-2 bg-gray-900/90 border-b border-gray-800">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-gray-200">{selectedFile.path}</span>
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-gray-800 text-gray-400 uppercase">
                  {selectedFile.category}
                </span>
              </div>
              <p className="text-[11px] text-gray-400 mt-0.5">{selectedFile.description}</p>
            </div>
            <button
              onClick={handleCopy}
              className="p-1.5 rounded-lg bg-gray-800 border border-gray-700 text-gray-300 hover:text-cyan-300 flex items-center gap-1 text-xs transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'COPIED' : 'COPY'}</span>
            </button>
          </div>
          <div className="flex-1 p-3 overflow-y-auto bg-[#030712] font-mono-code text-[11px] text-cyan-100/90 select-text leading-relaxed whitespace-pre-wrap">
            {selectedFile.content}
          </div>
        </div>
      </div>
    </div>
  );
};
