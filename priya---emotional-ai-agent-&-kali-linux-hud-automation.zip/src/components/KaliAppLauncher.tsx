import React, { useState, useEffect } from 'react';
import {
  Terminal,
  Search,
  Play,
  Sparkles,
  Shield,
  Layers,
  Globe,
  Database,
  Key,
  Radio,
  Binary,
  Code,
  FileSearch,
  Wifi,
  ArrowRight,
  ExternalLink,
} from 'lucide-react';
import { priyaVoice } from '../utils/speech';

export interface KaliTool {
  id: string;
  name: string;
  category: string;
  command: string;
  launchCommand?: string;
  actionCommand?: string;
  description: string;
  isRoot: boolean;
  icon?: string;
}

interface KaliAppLauncherProps {
  onRunCommand: (command: string, toolName?: string) => Promise<any>;
  onAskPriya: (prompt: string) => void;
  osMode?: 'kali' | 'windows';
}

export const KaliAppLauncher: React.FC<KaliAppLauncherProps> = ({
  onRunCommand,
  onAskPriya,
  osMode = 'kali',
}) => {
  const [tools, setTools] = useState<KaliTool[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [customTarget, setCustomTarget] = useState('127.0.0.1');
  const [executingToolId, setExecutingToolId] = useState<string | null>(null);

  useEffect(() => {
    fetch('/api/kali/tools')
      .then((res) => res.json())
      .then((data) => {
        if (data.tools) setTools(data.tools);
      })
      .catch((err) => console.error('Failed to load Kali tools:', err));
  }, []);

  const categories = [
    'All',
    'Browser & Web Tools',
    'System & Editor Integration',
    'Information Gathering',
    'Vulnerability Analysis',
    'Web Application Analysis',
    'Exploitation Tools',
    'Password Attacks',
    'Sniffing & Spoofing',
    'Privilege Escalation',
  ];

  const filteredTools = tools.filter((tool) => {
    const matchesCategory = selectedCategory === 'All' || tool.category === selectedCategory;
    const matchesSearch =
      tool.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tool.command.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tool.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleLaunchToolDirect = async (tool: KaliTool) => {
    setExecutingToolId(tool.id);
    let cmd = tool.command;
    if (customTarget && customTarget !== '127.0.0.1') {
      cmd = cmd.replace(/127\.0\.0\.1/g, customTarget);
    }
    priyaVoice.speak(`Executing ${tool.name} with root authority, Amit.`, 'focused');
    try {
      await onRunCommand(cmd, tool.name);
    } finally {
      setExecutingToolId(null);
    }
  };

  return (
    <div className="bg-gray-950/90 border border-cyan-900/40 rounded-2xl p-4 shadow-2xl backdrop-blur-md flex flex-col h-[650px] font-mono">
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between pb-3 border-b border-gray-800 gap-2">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-cyan-400" />
          <span className="text-xs font-bold text-cyan-300">
            KALI LINUX ROOT APPLICATIONS &amp; AUTOMATION DECK
          </span>
          <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800">
            {tools.length} Tools Loaded
          </span>
        </div>
        <div className="flex items-center gap-2 text-xs">
          <span className="text-gray-400 text-[11px]">Target Scope:</span>
          <input
            type="text"
            value={customTarget}
            onChange={(e) => setCustomTarget(e.target.value)}
            className="bg-gray-900 border border-gray-800 rounded-lg px-2.5 py-1 text-cyan-300 text-xs w-36 focus:outline-none focus:border-cyan-500"
          />
        </div>
      </div>

      {/* Category Pills & Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 py-2.5 border-b border-gray-900">
        <div className="flex items-center gap-1.5 overflow-x-auto text-[11px] max-w-[70%]">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-2.5 py-1 rounded-md transition-all shrink-0 ${
                selectedCategory === cat
                  ? 'bg-cyan-500/20 border border-cyan-400 text-cyan-200 font-semibold'
                  : 'bg-gray-900/60 border border-gray-800 text-gray-400 hover:text-gray-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
        <div className="relative">
          <Search className="w-3.5 h-3.5 text-gray-500 absolute left-2.5 top-2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search Kali tools..."
            className="pl-8 pr-3 py-1 bg-gray-900 border border-gray-800 rounded-lg text-xs text-gray-200 placeholder-gray-500 focus:outline-none focus:border-cyan-500"
          />
        </div>
      </div>

      {/* Tools Grid */}
      <div className="flex-1 overflow-y-auto mt-3 grid grid-cols-1 md:grid-cols-2 gap-3 pr-1">
        {filteredTools.map((tool) => {
          const isRunning = executingToolId === tool.id;
          return (
            <div
              key={tool.id}
              className="p-3 bg-gray-900/70 border border-gray-800 hover:border-cyan-900/60 rounded-xl flex flex-col justify-between transition-all"
            >
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <div>
                    <h3 className="text-xs font-bold text-gray-100 hover:text-cyan-300 transition-colors">
                      {tool.name}
                    </h3>
                    <span className="text-[10px] text-gray-500 uppercase">{tool.category}</span>
                  </div>
                  {tool.isRoot && (
                    <span className="px-1.5 py-0.5 rounded bg-red-950/80 border border-red-700/50 text-[10px] text-red-300 font-semibold flex items-center gap-1">
                      <Shield className="w-2.5 h-2.5 text-red-400" /> ROOT
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-gray-400 mb-2 leading-relaxed">{tool.description}</p>
                <div className="p-1.5 rounded bg-gray-950 border border-gray-800 text-[10px] text-cyan-300 mb-2 truncate">
                  &gt; {tool.command}
                </div>
              </div>

              <div className="flex items-center gap-1.5 pt-2 border-t border-gray-800/80">
                <button
                  onClick={() => handleLaunchToolDirect(tool)}
                  disabled={isRunning}
                  className="flex-1 py-1.5 px-2.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 text-black text-[11px] font-bold transition-all flex items-center justify-center gap-1"
                >
                  <Play className="w-3 h-3" />
                  <span>{isRunning ? 'DISPATCHING...' : 'EXECUTE TOOL'}</span>
                </button>
                <button
                  onClick={() => {
                    onAskPriya(`Priya, launch and run ${tool.name} with root authority for target ${customTarget}.`);
                  }}
                  className="px-2.5 py-1.5 rounded-lg bg-gray-800 hover:bg-pink-950 hover:border-pink-500/50 border border-gray-700 text-gray-300 hover:text-pink-300 text-[11px] transition-all flex items-center gap-1"
                  title="Ask Priya via Spoken AI"
                >
                  <Sparkles className="w-3 h-3 text-pink-400" />
                  <span>Ask Priya</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
