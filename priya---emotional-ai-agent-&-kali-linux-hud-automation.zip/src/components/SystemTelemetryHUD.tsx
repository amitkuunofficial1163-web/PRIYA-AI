import React, { useState, useEffect } from 'react';
import { Cpu, HardDrive, Wifi, Thermometer, Activity } from 'lucide-react';

export const SystemTelemetryHUD: React.FC<{ osMode?: 'kali' | 'windows' }> = ({ osMode = 'kali' }) => {
  const [telemetry, setTelemetry] = useState({
    cpuLoad: 24,
    ramMb: 4280,
    ramTotalMb: 16384,
    gpuTemp: 48,
    netRxKbps: 340,
    netTxKbps: 110,
    threatsBlocked: 16,
  });

  useEffect(() => {
    const fetchTelemetry = async () => {
      try {
        const res = await fetch('/api/telemetry');
        const data = await res.json();
        setTelemetry({
          cpuLoad: data.cpuLoad,
          ramMb: data.ramMb,
          ramTotalMb: data.ramTotalMb,
          gpuTemp: data.gpuTemp,
          netRxKbps: data.netRxKbps,
          netTxKbps: data.netTxKbps,
          threatsBlocked: data.threatsBlocked,
        });
      } catch (err) {
        setTelemetry((prev) => ({
          ...prev,
          cpuLoad: Math.floor(20 + Math.random() * 15),
          ramMb: Math.floor(4200 + Math.random() * 200),
          netRxKbps: Math.floor(200 + Math.random() * 250),
        }));
      }
    };
    fetchTelemetry();
    const interval = setInterval(fetchTelemetry, 3500);
    return () => clearInterval(interval);
  }, []);

  const ramPercent = Math.round((telemetry.ramMb / telemetry.ramTotalMb) * 100);

  return (
    <div className="bg-gray-950/80 border border-gray-800/80 rounded-xl p-3 shadow-xl backdrop-blur-md font-mono">
      <div className="flex items-center justify-between mb-2">
        <span className="text-[11px] font-bold text-gray-300 flex items-center gap-1.5">
          <Activity className="w-3.5 h-3.5 text-cyan-400" />
          SYSTEM TELEMETRY &bull; LAUNCH AUTOMATION HOOKS ARMED
        </span>
        <span className="text-[10px] text-cyan-400">
          {osMode === 'kali' ? '● KALI ROLLING 6.6' : '● WIN11 HYPER-V'}
        </span>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
        {/* CPU */}
        <div className="bg-gray-900/80 border border-gray-800 rounded-lg p-2">
          <div className="flex justify-between text-gray-400 text-[10px] mb-1">
            <span className="flex items-center gap-1"><Cpu className="w-3 h-3 text-cyan-400" /> CPU</span>
            <span className="text-cyan-300 font-bold">{telemetry.cpuLoad}%</span>
          </div>
          <div className="w-full bg-gray-950 rounded-full h-1.5 overflow-hidden">
            <div
              className="bg-cyan-400 h-full rounded-full transition-all duration-300"
              style={{ width: `${telemetry.cpuLoad}%` }}
            />
          </div>
        </div>
        {/* RAM */}
        <div className="bg-gray-900/80 border border-gray-800 rounded-lg p-2">
          <div className="flex justify-between text-gray-400 text-[10px] mb-1">
            <span className="flex items-center gap-1"><HardDrive className="w-3 h-3 text-purple-400" /> RAM</span>
            <span className="text-purple-300 font-bold">{ramPercent}%</span>
          </div>
          <div className="w-full bg-gray-950 rounded-full h-1.5 overflow-hidden">
            <div
              className="bg-purple-400 h-full rounded-full transition-all duration-300"
              style={{ width: `${ramPercent}%` }}
            />
          </div>
        </div>
        {/* GPU Temp */}
        <div className="bg-gray-900/80 border border-gray-800 rounded-lg p-2">
          <div className="flex justify-between text-gray-400 text-[10px] mb-1">
            <span className="flex items-center gap-1"><Thermometer className="w-3 h-3 text-amber-400" /> GPU TEMP</span>
            <span className="text-amber-300 font-bold">{telemetry.gpuTemp}°C</span>
          </div>
          <div className="w-full bg-gray-950 rounded-full h-1.5 overflow-hidden">
            <div
              className="bg-amber-400 h-full rounded-full transition-all duration-300"
              style={{ width: `${(telemetry.gpuTemp / 90) * 100}%` }}
            />
          </div>
        </div>
        {/* Network & Threats */}
        <div className="bg-gray-900/80 border border-gray-800 rounded-lg p-2">
          <div className="flex justify-between text-gray-400 text-[10px] mb-1">
            <span className="flex items-center gap-1"><Wifi className="w-3 h-3 text-emerald-400" /> NET I/O</span>
            <span className="text-emerald-300 font-bold">↑{telemetry.netTxKbps} ↓{telemetry.netRxKbps}</span>
          </div>
          <div className="flex items-center justify-between text-[10px] text-gray-500 pt-0.5">
            <span>Threats Blocked:</span>
            <span className="text-emerald-400 font-bold">{telemetry.threatsBlocked}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
