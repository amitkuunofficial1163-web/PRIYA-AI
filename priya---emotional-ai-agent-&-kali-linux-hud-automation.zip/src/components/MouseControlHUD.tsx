import React, { useState, useEffect } from 'react';
import {
  MousePointer,
  Crosshair,
  Sparkles,
  Move,
  Target,
} from 'lucide-react';
import { priyaVoice } from '../utils/speech';

export interface MouseEventState {
  x: number;
  y: number;
  action: 'idle' | 'move' | 'click' | 'double_click' | 'drag' | 'scroll';
  targetLabel?: string;
  isControlling: boolean;
}

interface MouseControlHUDProps {
  onExecuteMouseAction: (
    action: 'move' | 'click' | 'double_click' | 'drag' | 'scroll',
    x: number,
    y: number,
    targetLabel?: string
  ) => Promise<any>;
  onAskPriya: (prompt: string) => void;
  externalMouseState?: MouseEventState;
}

export const MouseControlHUD: React.FC<MouseControlHUDProps> = ({
  onExecuteMouseAction,
  onAskPriya,
  externalMouseState,
}) => {
  const [cursorPos, setCursorPos] = useState<{ x: number; y: number }>({ x: 520, y: 320 });
  const [activeAction, setActiveAction] = useState<string>('idle');
  const [activeTarget, setActiveTarget] = useState<string>('Ready for operator order');
  const [isAnimating, setIsAnimating] = useState(false);
  const [clickEffect, setClickEffect] = useState<{ x: number; y: number; active: boolean }>({
    x: 0,
    y: 0,
    active: false,
  });

  useEffect(() => {
    if (externalMouseState && externalMouseState.isControlling) {
      animateCursorTo(
        externalMouseState.x,
        externalMouseState.y,
        externalMouseState.action,
        externalMouseState.targetLabel
      );
    }
  }, [externalMouseState]);

  const animateCursorTo = (
    destX: number,
    destY: number,
    action: string = 'click',
    targetDesc?: string
  ) => {
    setIsAnimating(true);
    setActiveAction(action);
    if (targetDesc) setActiveTarget(targetDesc);

    const startX = cursorPos.x;
    const startY = cursorPos.y;
    const duration = 500;
    const startTime = performance.now();

    const step = (now: number) => {
      const elapsed = now - startTime;
      const progress = Math.min(1, elapsed / duration);
      const ease = 1 - Math.pow(1 - progress, 3);
      const curX = Math.round(startX + (destX - startX) * ease);
      const curY = Math.round(startY + (destY - startY) * ease);
      setCursorPos({ x: curX, y: curY });

      if (progress < 1) {
        requestAnimationFrame(step);
      } else {
        if (action.includes('click')) {
          setClickEffect({ x: destX, y: destY, active: true });
          setTimeout(() => setClickEffect((prev) => ({ ...prev, active: false })), 600);
        }
        setIsAnimating(false);
      }
    };
    requestAnimationFrame(step);
  };

  const handleOrder = async (
    action: 'move' | 'click' | 'double_click' | 'drag' | 'scroll',
    x: number,
    y: number,
    target: string
  ) => {
    animateCursorTo(x, y, action, target);
    priyaVoice.speak(
      `Moving mouse to ${target} and executing ${action} under your order, Amit.`,
      'focused'
    );
    await onExecuteMouseAction(action, x, y, target);
  };

  const targetPresets = [
    {
      name: 'Kali Terminal Prompt',
      x: 320,
      y: 560,
      desc: 'Moves cursor to root command input prompt & clicks',
      action: 'click' as const,
    },
    {
      name: 'Playwright Browser Viewport',
      x: 640,
      y: 280,
      desc: 'Focuses active Chromium DOM content session',
      action: 'click' as const,
    },
    {
      name: 'VS Code Editor Buffer',
      x: 480,
      y: 350,
      desc: 'Focuses Visual Studio Code active loot script tab',
      action: 'click' as const,
    },
    {
      name: 'Nmap Port Matrix',
      x: 620,
      y: 350,
      desc: 'Selects Nmap target specification and network scope',
      action: 'click' as const,
    },
    {
      name: 'Burp Suite Intercept Tab',
      x: 260,
      y: 220,
      desc: 'Toggles HTTP packet interception on 127.0.0.1:8080',
      action: 'double_click' as const,
    },
    {
      name: 'Wireshark eth0 Interface',
      x: 540,
      y: 190,
      desc: 'Double-clicks to trigger live packet capture',
      action: 'double_click' as const,
    },
  ];

  return (
    <div className="bg-gray-950/95 border border-cyan-900/50 rounded-2xl p-4 shadow-2xl backdrop-blur-md flex flex-col gap-3 font-mono">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between pb-3 border-b border-gray-800 gap-2">
        <div className="flex items-center gap-2">
          <MousePointer className="w-4 h-4 text-amber-400" />
          <span className="text-xs font-bold text-amber-300">
            REAL-TIME MOUSE CONTROLLER &amp; CURSOR OVERLAY
          </span>
          <span className="text-[10px] px-2 py-0.5 rounded bg-amber-950/80 text-amber-300 border border-amber-800 font-semibold">
            CONTROL BY ORDER ACTIVE
          </span>
        </div>
        <div className="flex items-center gap-3 text-xs text-gray-400">
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-gray-900 border border-gray-800">
            <Crosshair className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-cyan-300 font-bold">X: {cursorPos.x}</span>
            <span className="text-cyan-300 font-bold">Y: {cursorPos.y}</span>
          </div>
          <span className="text-[10px] uppercase text-pink-300 font-bold">
            {isAnimating ? `ACTION: ${activeAction}` : 'STATUS: IDLE'}
          </span>
        </div>
      </div>

      {/* Trackpad Stage / Interactive Virtual Screen */}
      <div className="relative h-64 bg-[#020617] rounded-xl border border-cyan-900/50 overflow-hidden shadow-inner flex flex-col justify-between p-3 select-none">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#082f4915_1px,transparent_1px),linear-gradient(to_bottom,#082f4915_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none" />
        <div className="relative z-10 flex items-center justify-between text-[11px] text-gray-500">
          <span className="flex items-center gap-1 text-cyan-400">
            <Sparkles className="w-3 h-3" />
            <span>Priya Hardware Display Surface (:0.0)</span>
          </span>
          <span className="text-amber-400 font-semibold truncate max-w-xs">
            Target: {activeTarget}
          </span>
        </div>

        {/* Interactive Click Area */}
        <div
          onClick={(e) => {
            const rect = e.currentTarget.getBoundingClientRect();
            const relX = Math.round(((e.clientX - rect.left) / rect.width) * 1024);
            const relY = Math.round(((e.clientY - rect.top) / rect.height) * 768);
            handleOrder('click', relX, relY, `User Clicked Screen (${relX}, ${relY})`);
          }}
          className="absolute inset-0 cursor-crosshair z-0"
          title="Click to command cursor placement!"
        />

        {/* Virtual Cursor */}
        <div
          className="absolute pointer-events-none transition-transform duration-75 z-20"
          style={{
            left: `${(cursorPos.x / 1024) * 100}%`,
            top: `${(cursorPos.y / 768) * 100}%`,
            transform: 'translate(-4px, -4px)',
          }}
        >
          <div className="relative">
            <svg
              className="w-6 h-6 text-amber-400 filter drop-shadow-[0_0_8px_rgba(251,191,36,0.8)]"
              viewBox="0 0 24 24"
              fill="currentColor"
            >
              <path d="M4 2l16 11-8 2-4 7L4 2z" />
            </svg>
            <div className="absolute left-6 top-0 px-1.5 py-0.5 rounded bg-black/90 border border-amber-500 text-[9px] text-amber-200 whitespace-nowrap shadow-lg">
              ({cursorPos.x}, {cursorPos.y})
            </div>
          </div>
        </div>

        {clickEffect.active && (
          <div
            className="absolute pointer-events-none rounded-full border-2 border-amber-400 animate-ping z-10"
            style={{
              left: `${(clickEffect.x / 1024) * 100}%`,
              top: `${(clickEffect.y / 768) * 100}%`,
              width: '36px',
              height: '36px',
              transform: 'translate(-50%, -50%)',
            }}
          />
        )}

        <div className="relative z-10 flex items-center justify-between text-[10px] text-gray-500 pt-1">
          <span>Click anywhere to command mouse cursor</span>
          <span className="text-cyan-400">Resolution: 1024 x 768 Hooked</span>
        </div>
      </div>

      {/* Preset Target Orders */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-1.5 text-xs font-bold text-gray-300">
            <Target className="w-3.5 h-3.5 text-cyan-400" />
            <span>ORDER PRIYA: TARGET PRESETS</span>
          </div>
          <span className="text-[10px] text-gray-500">Instant Hardware Cursor Dispatch</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
          {targetPresets.map((tgt, idx) => (
            <button
              key={idx}
              onClick={() => handleOrder(tgt.action, tgt.x, tgt.y, tgt.name)}
              disabled={isAnimating}
              className="p-2 rounded-xl bg-gray-900/80 border border-gray-800 hover:border-amber-500/60 hover:bg-amber-950/20 text-left transition-all group disabled:opacity-40"
            >
              <div className="flex items-center justify-between text-xs font-bold text-gray-200 group-hover:text-amber-300">
                <span className="truncate">{tgt.name}</span>
                <span className="text-[10px] px-1 py-0.2 rounded bg-gray-950 border border-gray-800 text-gray-400 uppercase">
                  {tgt.action}
                </span>
              </div>
              <p className="text-[10px] text-gray-400 mt-0.5 truncate">{tgt.desc}</p>
              <div className="text-[9px] text-cyan-400/90 font-mono-code mt-1">
                Coord: ({tgt.x}, {tgt.y})
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Manual Actions */}
      <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-gray-800 text-xs">
        <button
          onClick={() => handleOrder('click', cursorPos.x, cursorPos.y, 'Left Click Target')}
          disabled={isAnimating}
          className="flex-1 py-1.5 px-3 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-black font-bold transition-all disabled:opacity-40"
        >
          LEFT CLICK
        </button>
        <button
          onClick={() => handleOrder('double_click', cursorPos.x, cursorPos.y, 'Double Click Target')}
          disabled={isAnimating}
          className="flex-1 py-1.5 px-3 rounded-lg bg-gray-800 hover:bg-gray-700 text-cyan-300 font-bold border border-gray-700 transition-all disabled:opacity-40"
        >
          DOUBLE CLICK
        </button>
        <button
          onClick={() => handleOrder('click', cursorPos.x, cursorPos.y, 'Right Click Target')}
          disabled={isAnimating}
          className="flex-1 py-1.5 px-3 rounded-lg bg-gray-800 hover:bg-gray-700 text-amber-300 font-bold border border-gray-700 transition-all disabled:opacity-40"
        >
          RIGHT CLICK
        </button>
        <button
          onClick={() =>
            onAskPriya(
              'Priya, control my mouse: move to the terminal prompt and left click with root privileges.'
            )
          }
          className="py-1.5 px-3 rounded-lg bg-pink-950/80 hover:bg-pink-900 border border-pink-700/60 text-pink-200 font-bold transition-all flex items-center gap-1"
        >
          <Sparkles className="w-3 h-3 text-pink-400" />
          <span>Order via Voice</span>
        </button>
      </div>
    </div>
  );
};
