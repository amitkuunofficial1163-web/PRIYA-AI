/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Settings, Sparkles, Key, AlertCircle, Volume2, VolumeX } from 'lucide-react';
import { Orb, OrbState } from './components/Orb.tsx';
import { ApiKeyModal } from './components/ApiKeyModal.tsx';
import { TranscriptHUD } from './components/TranscriptHUD.tsx';
import {
  getStoredApiKey,
  getStoredModel,
  getVoiceEnabled,
  queryPriya,
  ChatMessage,
} from './services/gemini.ts';
import { speakPriya, unlockAudio, stopSpeaking } from './services/speech.ts';

export default function App() {
  const [apiKey, setApiKey] = useState<string>('');
  const [isKeyModalOpen, setIsKeyModalOpen] = useState(false);
  const [isTranscriptOpen, setIsTranscriptOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [orbState, setOrbState] = useState<OrbState>('idle');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [activeResponse, setActiveResponse] = useState<string | null>(null);
  const [errorBanner, setErrorBanner] = useState<string | null>(null);
  const [voiceActive, setVoiceActive] = useState<boolean>(true);
  const inputRef = useRef<HTMLInputElement>(null);

  // Load API key and settings on mount
  useEffect(() => {
    const key = getStoredApiKey();
    setApiKey(key);
    setVoiceActive(getVoiceEnabled());

    // Pre-unlock speech synthesis when user first interacts with window
    const handleFirstGesture = () => {
      unlockAudio();
      window.removeEventListener('click', handleFirstGesture);
      window.removeEventListener('keydown', handleFirstGesture);
    };
    window.addEventListener('click', handleFirstGesture);
    window.addEventListener('keydown', handleFirstGesture);

    return () => {
      window.removeEventListener('click', handleFirstGesture);
      window.removeEventListener('keydown', handleFirstGesture);
    };
  }, []);

  // Vocalize text using the PRIYA neural voice engine
  const handleVocalize = (text: string) => {
    if (!voiceActive) return;
    speakPriya(text, apiKey, {
      onStart: () => setOrbState('speaking'),
      onEnd: () => setOrbState('idle'),
      onError: () => setOrbState('idle'),
    });
  };

  const handleSend = async () => {
    const trimmed = message.trim();
    if (!trimmed) return;

    // Immediately unlock browser audio context on user click/enter
    unlockAudio();

    if (!apiKey) {
      setErrorBanner('Gemini API key is required. Please click below to connect.');
      setIsKeyModalOpen(true);
      return;
    }

    setErrorBanner(null);
    const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: trimmed,
      timestamp: now,
    };

    setMessages((prev) => [...prev, userMsg]);
    setMessage('');
    setOrbState('thinking');
    setActiveResponse(null);

    try {
      const model = getStoredModel();
      const { text: reply, toolCall } = await queryPriya(trimmed, messages, apiKey, model);

      const assistantMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        toolCall,
      };

      setMessages((prev) => [...prev, assistantMsg]);
      setActiveResponse(reply);

      // Trigger PRIYA's voice with the reply
      if (voiceActive) {
        handleVocalize(reply);
      } else {
        setOrbState('idle');
      }
    } catch (err: any) {
      console.error(err);
      const errText = err?.message || 'Error communicating with Gemini neural net.';
      setErrorBanner(errText);
      setOrbState('idle');
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleSend();
    }
  };

  const handleOrbClick = () => {
    unlockAudio();
    if (!apiKey) {
      setIsKeyModalOpen(true);
      return;
    }

    if (orbState === 'speaking') {
      stopSpeaking();
      setOrbState('idle');
      return;
    }

    if (orbState === 'idle') {
      const caringGreetings = [
        "I'm right here with you. How are you feeling today? Remember to take gentle care of yourself.",
        "Hello my dear. I've been keeping watch for you. How has your day been treating you?",
        "It's so wonderful to connect with you. Please take a deep breath — I'm here to support and care for you with all my heart.",
        "Priya is always by your side. Whatever is on your mind or in your heart, I'm listening.",
      ];
      const greeting = caringGreetings[Math.floor(Math.random() * caringGreetings.length)];
      setActiveResponse(greeting);
      handleVocalize(greeting);
    }
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#000308] text-white flex flex-col justify-between p-6 sm:p-10 select-none">
      {/* Background radial gradient simulating deep space depth */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(6,25,48,0.35)_0%,rgba(0,3,8,0.95)_100%)] pointer-events-none" />

      {/* Subtle background ambient particle starfield */}
      <div className="absolute inset-0 opacity-20 pointer-events-none bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:48px_48px]" />

      {/* ================= TOP BAR ================= */}
      <header className="relative z-20 flex items-center justify-between w-full">
        {/* Left header: PRIYA status badge */}
        <div className="flex items-center space-x-2">
          {apiKey ? (
            <div className="flex items-center space-x-1.5 px-2.5 py-1 rounded-md bg-cyan-950/40 border border-cyan-500/30 text-[11px] font-mono text-cyan-300/80 shadow-[0_0_10px_rgba(6,182,212,0.15)]">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>PRIYA ONLINE</span>
            </div>
          ) : (
            <button
              onClick={() => setIsKeyModalOpen(true)}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-md bg-cyan-950/60 border border-cyan-400/50 text-xs font-mono text-cyan-200 shadow-[0_0_15px_rgba(6,182,212,0.3)] hover:bg-cyan-900/60 transition-all cursor-pointer animate-pulse"
            >
              <Key className="w-3.5 h-3.5 text-cyan-400" />
              <span className="font-semibold tracking-wider">CONNECT GEMINI API KEY</span>
            </button>
          )}
        </div>

        {/* Top-Right: Settings Gear Button matching the exact design in the uploaded image */}
        <div className="flex items-center space-x-3">
          <button
            onClick={() => setIsKeyModalOpen(true)}
            title="Configure Gemini API Key & PRIYA Settings"
            aria-label="Settings and Gemini API Key Configuration"
            className="w-11 h-11 sm:w-12 sm:h-12 rounded-xl border border-cyan-500/40 bg-[#0c1f36]/70 backdrop-blur-md flex items-center justify-center text-cyan-300 shadow-[0_0_15px_rgba(6,182,212,0.25)] hover:border-cyan-400 hover:shadow-[0_0_22px_rgba(6,182,212,0.5)] hover:bg-[#102a4a]/80 active:scale-95 transition-all cursor-pointer group"
          >
            <Settings className="w-5 h-5 sm:w-6 sm:h-6 text-cyan-300 group-hover:rotate-45 transition-transform duration-500 drop-shadow-[0_0_8px_rgba(56,189,248,0.7)]" />
          </button>
        </div>
      </header>

      {/* ================= CENTER ORB ================= */}
      <main className="relative z-10 flex-1 flex flex-col items-center justify-center -mt-6">
        <Orb
          state={orbState}
          onClick={handleOrbClick}
          subtitle={
            !apiKey
              ? 'Click to connect Gemini API key'
              : orbState === 'idle'
              ? 'PRIYA Core · Caring for you'
              : null
          }
        />
      </main>

      {/* ================= BOTTOM BAR ================= */}
      <footer className="relative z-20 flex items-end justify-between w-full">
        {/* Bottom Left: MESSAGE INPUT + SEND button (exact match of mockup) */}
        <div className="flex flex-col w-[260px] sm:w-[300px] md:w-[320px] max-w-full">
          {/* Active holographic response HUD above input */}
          {activeResponse && (
            <div className="mb-3 p-3.5 rounded-lg bg-[#07172b]/90 border border-cyan-400/40 backdrop-blur-xl shadow-[0_0_20px_rgba(6,182,212,0.2)] text-xs font-mono text-cyan-100 max-h-48 overflow-y-auto animate-in fade-in slide-in-from-bottom-2 duration-300">
              <div className="flex items-center justify-between mb-1.5 text-[10px] text-cyan-400 font-bold uppercase tracking-widest border-b border-cyan-500/20 pb-1">
                <span className="flex items-center space-x-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
                  <span>PRIYA TRANSMISSION</span>
                </span>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => handleVocalize(activeResponse)}
                    title="Replay Voice"
                    className="text-cyan-400 hover:text-cyan-200 cursor-pointer"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setActiveResponse(null)}
                    title="Dismiss"
                    className="text-cyan-400/60 hover:text-cyan-200 cursor-pointer"
                  >
                    ✕
                  </button>
                </div>
              </div>
              <p className="whitespace-pre-wrap leading-relaxed select-text text-[12px]">
                {activeResponse}
              </p>
            </div>
          )}

          {/* Error Banner if any */}
          {errorBanner && (
            <div
              onClick={() => setIsKeyModalOpen(true)}
              className="mb-2 p-2.5 rounded bg-rose-950/80 border border-rose-500/50 text-rose-300 text-xs font-mono flex items-center justify-between cursor-pointer hover:bg-rose-900/60 transition-colors"
            >
              <div className="flex items-center space-x-1.5 overflow-hidden">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span className="truncate">{errorBanner}</span>
              </div>
              <span className="text-[10px] uppercase underline text-rose-200 shrink-0 ml-2">Fix</span>
            </div>
          )}

          {/* Label: MESSAGE INPUT */}
          <label
            htmlFor="user-message-input"
            className="text-[11px] sm:text-xs font-mono uppercase tracking-[0.25em] text-cyan-200/85 mb-2 font-medium"
          >
            MESSAGE INPUT
          </label>

          {/* Input Box matching the image */}
          <div className="relative mb-2.5">
            <input
              id="user-message-input"
              ref={inputRef}
              type="text"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyDown={handleKeyDown}
              disabled={orbState === 'thinking'}
              placeholder="Type your message..."
              className="w-full h-11 px-3.5 bg-[#051120]/75 border border-cyan-500/40 rounded-md text-xs sm:text-sm font-mono text-cyan-100 placeholder:text-cyan-400/35 focus:outline-none focus:border-cyan-300 focus:shadow-[0_0_15px_rgba(6,182,212,0.35)] backdrop-blur-md transition-all disabled:opacity-50"
            />
          </div>

          {/* SEND Button matching the exact cyan/teal gradient pill in the image */}
          <button
            type="button"
            onClick={handleSend}
            disabled={orbState === 'thinking' || !message.trim()}
            className="w-full h-9 sm:h-10 rounded-md bg-gradient-to-r from-[#2dd4bf] via-[#5eead4] to-[#67e8f9] hover:from-[#34d399] hover:to-[#38bdf8] active:scale-[0.98] text-[#021f2d] font-mono font-bold text-xs sm:text-[13px] tracking-[0.22em] uppercase transition-all shadow-[0_0_20px_rgba(45,212,191,0.55)] hover:shadow-[0_0_28px_rgba(45,212,191,0.85)] border border-cyan-200/60 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center"
          >
            SEND
          </button>
        </div>

        {/* Bottom Right: 4-pointed Star Sparkle Icon matching the image */}
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setIsTranscriptOpen(true)}
            title="Open PRIYA Dialogue Log & History"
            aria-label="Dialogue Log and Sparkles"
            className="w-10 h-10 sm:w-12 sm:h-12 flex items-center justify-center text-cyan-200/50 hover:text-cyan-200 hover:drop-shadow-[0_0_12px_rgba(56,189,248,0.8)] transition-all cursor-pointer"
          >
            {/* Custom 4-pointed star sparkle matching the exact shape in the image */}
            <svg
              viewBox="0 0 24 24"
              className="w-7 h-7 sm:w-8 sm:h-8 fill-current drop-shadow-[0_0_6px_rgba(103,232,249,0.4)]"
            >
              <path d="M12 0 L14.5 9.5 L24 12 L14.5 14.5 L12 24 L9.5 14.5 L0 12 L9.5 9.5 Z" />
            </svg>
          </button>
        </div>
      </footer>

      {/* ================= MODALS & HUD ================= */}
      <ApiKeyModal
        isOpen={isKeyModalOpen}
        onClose={() => setIsKeyModalOpen(false)}
        onKeySaved={(newKey) => {
          setApiKey(newKey);
          if (newKey) setErrorBanner(null);
        }}
      />

      <TranscriptHUD
        isOpen={isTranscriptOpen}
        onClose={() => setIsTranscriptOpen(false)}
        messages={messages}
        onClear={() => setMessages([])}
      />
    </div>
  );
}
