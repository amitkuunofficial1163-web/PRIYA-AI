import React, { useState, useEffect } from 'react';
import { Key, Eye, EyeOff, CheckCircle2, AlertTriangle, ShieldCheck, Zap, X, ExternalLink, Trash2 } from 'lucide-react';
import {
  getStoredApiKey,
  saveStoredApiKey,
  clearStoredApiKey,
  testGeminiApiKey,
  AVAILABLE_MODELS,
  getStoredModel,
  saveStoredModel,
  getVoiceEnabled,
  saveVoiceEnabled,
} from '../services/gemini.ts';
import { speakPriya } from '../services/speech.ts';

interface ApiKeyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onKeySaved: (key: string) => void;
}

export const ApiKeyModal: React.FC<ApiKeyModalProps> = ({ isOpen, onClose, onKeySaved }) => {
  const [apiKey, setApiKey] = useState('');
  const [showKey, setShowKey] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);
  const [isTesting, setIsTesting] = useState(false);
  const [selectedModel, setSelectedModel] = useState(getStoredModel());
  const [voiceEnabled, setVoiceEnabled] = useState(getVoiceEnabled());

  useEffect(() => {
    if (isOpen) {
      const currentKey = getStoredApiKey();
      setApiKey(currentKey);
      setSelectedModel(getStoredModel());
      setVoiceEnabled(getVoiceEnabled());
      setStatusMessage(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSave = () => {
    if (!apiKey.trim()) {
      setStatusMessage({ type: 'error', text: 'Please enter a valid API key.' });
      return;
    }
    saveStoredApiKey(apiKey);
    saveStoredModel(selectedModel);
    saveVoiceEnabled(voiceEnabled);
    setStatusMessage({ type: 'success', text: 'Gemini API Key securely stored in local storage!' });
    onKeySaved(apiKey.trim());
  };

  const handleTestConnection = async () => {
    if (!apiKey.trim()) {
      setStatusMessage({ type: 'error', text: 'Please enter an API key before testing.' });
      return;
    }
    setIsTesting(true);
    setStatusMessage({ type: 'info', text: 'Testing connection to Google Gemini API...' });

    const result = await testGeminiApiKey(apiKey.trim(), selectedModel);
    setIsTesting(false);

    if (result.success) {
      setStatusMessage({ type: 'success', text: result.message });
      if (result.activeModel) {
        setSelectedModel(result.activeModel);
        saveStoredModel(result.activeModel);
      }
      // auto save if valid
      saveStoredApiKey(apiKey);
      onKeySaved(apiKey.trim());
    } else {
      setStatusMessage({ type: 'error', text: result.message });
    }
  };

  const handleClear = () => {
    clearStoredApiKey();
    setApiKey('');
    setStatusMessage({ type: 'info', text: 'API key removed from local storage.' });
    onKeySaved('');
  };

  const isConfigured = Boolean(apiKey.trim());

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-[#071322]/95 border border-cyan-500/40 rounded-xl shadow-[0_0_35px_rgba(6,182,212,0.25)] overflow-hidden text-cyan-50">
        {/* Top Sci-Fi Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-cyan-500/20 bg-[#0c1f36]/70">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded-lg bg-cyan-950/80 border border-cyan-400/50 flex items-center justify-center text-cyan-300 shadow-[0_0_10px_rgba(6,182,212,0.3)]">
              <Key className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-semibold tracking-wider font-mono uppercase text-cyan-200">
                Gemini API Connection
              </h2>
              <p className="text-xs text-cyan-400/60 font-mono">PRIYA Neural Uplink Setup</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md text-cyan-400/70 hover:text-cyan-200 hover:bg-cyan-950/50 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {/* Security Banner */}
          <div className="flex items-start space-x-3 p-3 rounded-lg bg-cyan-950/40 border border-cyan-500/20 text-xs font-mono text-cyan-300/80">
            <ShieldCheck className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
            <span>
              <strong>Secure Local Storage:</strong> Your Gemini API key is stored locally in your browser's <code className="text-cyan-200 bg-cyan-900/40 px-1 py-0.5 rounded">localStorage</code>. It is never logged or sent to any third-party backend.
            </span>
          </div>

          {/* Key Input Field */}
          <div>
            <div className="flex justify-between items-center mb-1.5">
              <label className="text-xs font-mono uppercase tracking-wider text-cyan-200">
                Gemini API Key
              </label>
              <a
                href="https://aistudio.google.com/apikey"
                target="_blank"
                rel="noreferrer"
                className="text-xs font-mono text-cyan-400 hover:text-cyan-200 flex items-center space-x-1 underline decoration-cyan-500/50 underline-offset-2"
              >
                <span>Get Free Key</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
            <div className="relative">
              <input
                type={showKey ? 'text' : 'password'}
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="AIzaSy..."
                className="w-full bg-[#030914] border border-cyan-500/40 rounded-lg px-3.5 py-2.5 pr-10 text-sm font-mono text-cyan-100 placeholder:text-cyan-600/40 focus:outline-none focus:border-cyan-400 focus:shadow-[0_0_15px_rgba(6,182,212,0.3)] transition-all"
              />
              <button
                type="button"
                onClick={() => setShowKey(!showKey)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-cyan-400/60 hover:text-cyan-200"
              >
                {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Model Selection */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-mono uppercase tracking-wider text-cyan-200 mb-1.5">
                Gemini Model
              </label>
              <select
                value={selectedModel}
                onChange={(e) => setSelectedModel(e.target.value)}
                className="w-full bg-[#030914] border border-cyan-500/40 rounded-lg px-3 py-2 text-xs font-mono text-cyan-200 focus:outline-none focus:border-cyan-400 cursor-pointer"
              >
                {AVAILABLE_MODELS.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.name} ({m.desc})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-mono uppercase tracking-wider text-cyan-200">
                  Voice Output (Speech)
                </label>
                {voiceEnabled && (
                  <button
                    type="button"
                    onClick={() => speakPriya('Hello! This is PRIYA, neural voice fully operational.', apiKey)}
                    className="text-[11px] font-mono text-cyan-400 hover:text-cyan-200 underline cursor-pointer"
                  >
                    Test Voice 🔊
                  </button>
                )}
              </div>
              <button
                type="button"
                onClick={() => setVoiceEnabled(!voiceEnabled)}
                className={`w-full py-2 px-3 rounded-lg border text-xs font-mono flex items-center justify-between transition-all ${
                  voiceEnabled
                    ? 'bg-cyan-950/60 border-cyan-400 text-cyan-200 shadow-[0_0_10px_rgba(6,182,212,0.2)]'
                    : 'bg-[#030914] border-cyan-900/50 text-cyan-500/60'
                }`}
              >
                <span>Vocal Response:</span>
                <span className={voiceEnabled ? 'text-cyan-300 font-bold' : 'text-slate-500'}>
                  {voiceEnabled ? 'ENABLED' : 'MUTED'}
                </span>
              </button>
            </div>
          </div>

          {/* Integrated PRIYA Actions Overview */}
          <div className="p-2.5 rounded-lg bg-[#040d18] border border-cyan-500/20 text-[11px] font-mono text-cyan-400/80">
            <span className="text-cyan-200 font-semibold block mb-1">
              ⚙️ PRIYA SUBSYSTEMS INTEGRATED:
            </span>
            <div className="flex flex-wrap gap-1.5 text-[10px]">
              <span className="px-1.5 py-0.5 rounded bg-cyan-950/60 border border-cyan-500/30">Weather Report</span>
              <span className="px-1.5 py-0.5 rounded bg-cyan-950/60 border border-cyan-500/30">Hardware Telemetry</span>
              <span className="px-1.5 py-0.5 rounded bg-cyan-950/60 border border-cyan-500/30">Web Search</span>
              <span className="px-1.5 py-0.5 rounded bg-cyan-950/60 border border-cyan-500/30">YouTube Audio/Video</span>
              <span className="px-1.5 py-0.5 rounded bg-cyan-950/60 border border-cyan-500/30">Smart Reminders</span>
              <span className="px-1.5 py-0.5 rounded bg-cyan-950/60 border border-cyan-500/30">Recallable Memory</span>
            </div>
          </div>

          {/* Status Message */}
          {statusMessage && (
            <div
              className={`flex items-start space-x-2 p-3 rounded-lg text-xs font-mono border ${
                statusMessage.type === 'success'
                  ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
                  : statusMessage.type === 'error'
                  ? 'bg-rose-950/40 border-rose-500/40 text-rose-300'
                  : 'bg-cyan-950/40 border-cyan-500/40 text-cyan-300'
              }`}
            >
              {statusMessage.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              ) : statusMessage.type === 'error' ? (
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              ) : (
                <Zap className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5 animate-spin" />
              )}
              <span className="break-all">{statusMessage.text}</span>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-2.5 pt-2">
            <button
              type="button"
              onClick={handleSave}
              className="flex-1 py-2.5 px-4 rounded-lg bg-gradient-to-r from-teal-400 to-cyan-400 hover:from-teal-300 hover:to-cyan-300 text-[#021824] font-mono font-bold text-xs tracking-wider uppercase transition-all shadow-[0_0_15px_rgba(45,212,191,0.4)] cursor-pointer"
            >
              Save Key Locally
            </button>

            <button
              type="button"
              onClick={handleTestConnection}
              disabled={isTesting || !apiKey.trim()}
              className="py-2.5 px-4 rounded-lg bg-[#0c1f36] border border-cyan-500/40 hover:border-cyan-300 text-cyan-200 font-mono text-xs tracking-wider uppercase transition-all hover:bg-cyan-900/40 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer flex items-center justify-center space-x-1.5"
            >
              <Zap className={`w-3.5 h-3.5 text-cyan-400 ${isTesting ? 'animate-spin' : ''}`} />
              <span>{isTesting ? 'Testing...' : 'Test Connection'}</span>
            </button>

            {isConfigured && (
              <button
                type="button"
                onClick={handleClear}
                title="Remove key from local storage"
                className="p-2.5 rounded-lg border border-rose-500/30 text-rose-400/80 hover:text-rose-200 hover:bg-rose-950/40 transition-colors flex items-center justify-center cursor-pointer"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Footer info */}
        <div className="px-6 py-3 border-t border-cyan-500/20 bg-[#030914] flex items-center justify-between text-[11px] font-mono text-cyan-400/50">
          <span>Status: {isConfigured ? 'Key Loaded' : 'Key Not Set'}</span>
          <button
            onClick={onClose}
            className="text-cyan-300 hover:underline cursor-pointer"
          >
            Close Window
          </button>
        </div>
      </div>
    </div>
  );
};
