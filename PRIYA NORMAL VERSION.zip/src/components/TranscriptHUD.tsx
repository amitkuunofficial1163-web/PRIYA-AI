import React from 'react';
import { X, Trash2, Copy, Check, MessageSquare } from 'lucide-react';
import { ChatMessage } from '../services/gemini.ts';

interface TranscriptHUDProps {
  isOpen: boolean;
  onClose: () => void;
  messages: ChatMessage[];
  onClear: () => void;
}

export const TranscriptHUD: React.FC<TranscriptHUDProps> = ({
  isOpen,
  onClose,
  messages,
  onClear,
}) => {
  const [copiedId, setCopiedId] = React.useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="fixed inset-y-0 right-0 z-40 w-full max-w-md bg-[#050e1b]/95 border-l border-cyan-500/30 backdrop-blur-xl shadow-[-10px_0_30px_rgba(2,132,199,0.25)] flex flex-col text-cyan-50 animate-in slide-in-from-right duration-300">
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-cyan-500/20 bg-[#08172b]">
        <div className="flex items-center space-x-2.5">
          <MessageSquare className="w-4 h-4 text-cyan-400" />
          <h3 className="font-mono text-sm uppercase tracking-widest text-cyan-200">
            Telemetry & Dialogue Log
          </h3>
        </div>
        <div className="flex items-center space-x-1">
          {messages.length > 0 && (
            <button
              onClick={onClear}
              title="Clear transcript"
              className="p-1.5 rounded text-cyan-400/60 hover:text-rose-400 hover:bg-rose-950/30 transition-colors"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="p-1.5 rounded text-cyan-400/60 hover:text-cyan-200 hover:bg-cyan-900/40 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Messages list */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-6 text-cyan-500/50 font-mono text-xs space-y-2">
            <span className="w-2 h-2 rounded-full bg-cyan-500/40 animate-ping" />
            <p>PRIYA COMM SYSTEM READY</p>
            <p className="text-[11px] text-cyan-600/60">No dialogue recorded in buffer.</p>
          </div>
        ) : (
          messages.map((msg) => (
            <div
              key={msg.id}
              className={`rounded-lg p-3 text-xs font-mono transition-all border ${
                msg.role === 'user'
                  ? 'bg-cyan-950/40 border-cyan-500/20 ml-6 text-cyan-100'
                  : 'bg-[#081b33]/60 border-cyan-400/30 mr-6 text-cyan-200 shadow-[0_0_15px_rgba(6,182,212,0.1)]'
              }`}
            >
              <div className="flex items-center justify-between mb-1 text-[10px] text-cyan-400/60">
                <span className="font-semibold uppercase tracking-wider">
                  {msg.role === 'user' ? 'Operator' : 'PRIYA'}
                </span>
                <div className="flex items-center space-x-2">
                  <span>{msg.timestamp}</span>
                  <button
                    onClick={() => handleCopy(msg.content, msg.id)}
                    className="hover:text-cyan-200"
                  >
                    {copiedId === msg.id ? (
                      <Check className="w-3 h-3 text-emerald-400" />
                    ) : (
                      <Copy className="w-3 h-3" />
                    )}
                  </button>
                </div>
              </div>
              {msg.toolCall && (
                <div className="mb-1.5 px-2 py-0.5 rounded bg-cyan-950/80 border border-cyan-400/40 text-[10px] text-cyan-300 font-mono inline-block">
                  ⚡ ACTION: {msg.toolCall.name.toUpperCase()}
                </div>
              )}
              <p className="whitespace-pre-wrap leading-relaxed select-text">{msg.content}</p>
            </div>
          ))
        )}
      </div>

      {/* Footer */}
      <div className="p-3 border-t border-cyan-500/20 bg-[#030914] text-[10px] font-mono text-cyan-400/50 flex justify-between">
        <span>BUFFER: {messages.length} MESSAGES</span>
        <span>ENCRYPTION: AES-256 LOCAL</span>
      </div>
    </div>
  );
};
