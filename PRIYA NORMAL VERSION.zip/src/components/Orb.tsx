import React, { useMemo } from 'react';

export type OrbState = 'idle' | 'listening' | 'thinking' | 'speaking';

interface OrbProps {
  state: OrbState;
  onClick?: () => void;
  subtitle?: string | null;
}

export const Orb: React.FC<OrbProps> = ({ state, onClick, subtitle }) => {
  // Glow intensity and colors depending on state
  const isThinking = state === 'thinking';
  const isSpeaking = state === 'speaking';
  const isListening = state === 'listening';

  return (
    <div className="relative flex flex-col items-center justify-center select-none pointer-events-auto">
      {/* Outer atmospheric aura bloom */}
      <div
        className={`absolute rounded-full transition-all duration-700 pointer-events-none ${
          isThinking
            ? 'w-[420px] h-[420px] bg-cyan-500/25 blur-3xl animate-pulse'
            : isSpeaking
            ? 'w-[440px] h-[440px] bg-sky-400/30 blur-3xl scale-105'
            : isListening
            ? 'w-[380px] h-[380px] bg-teal-400/20 blur-2xl'
            : 'w-[340px] h-[340px] bg-blue-600/20 blur-3xl animate-aura'
        }`}
      />

      {/* Secondary ambient soft glow */}
      <div
        className={`absolute rounded-full transition-all duration-500 pointer-events-none ${
          isThinking
            ? 'w-[300px] h-[300px] bg-cyan-400/35 blur-2xl'
            : isSpeaking
            ? 'w-[320px] h-[320px] bg-sky-300/35 blur-2xl'
            : 'w-[260px] h-[260px] bg-blue-500/25 blur-2xl'
        }`}
      />

      {/* Sci-fi orbital resonance rings when thinking/speaking */}
      {(isThinking || isSpeaking) && (
        <>
          <div className="absolute w-[260px] h-[260px] rounded-full border border-cyan-400/30 animate-ring-slow pointer-events-none" />
          <div className="absolute w-[290px] h-[290px] rounded-full border border-dashed border-sky-400/20 animate-ring-rev pointer-events-none" />
        </>
      )}

      {/* Main 3D Spherical Orb Container */}
      <div
        onClick={onClick}
        title="PRIYA Core"
        className={`relative w-44 h-44 sm:w-52 sm:h-52 md:w-60 md:h-60 rounded-full cursor-pointer transition-transform duration-500 ${
          isThinking
            ? 'scale-105'
            : isSpeaking
            ? 'scale-108'
            : 'hover:scale-103'
        }`}
      >
        {/* Photorealistic 3D Sphere rendered with SVG radial lighting matching the image */}
        <svg
          viewBox="0 0 200 200"
          className="w-full h-full rounded-full drop-shadow-[0_0_40px_rgba(37,99,235,0.45)]"
        >
          <defs>
            {/* Primary 3D Sphere illumination: light source at upper-left */}
            <radialGradient id="sphereGrad" cx="38%" cy="34%" r="66%" fx="34%" fy="28%">
              <stop offset="0%" stopColor="#a5f3fc" stopOpacity="0.95" />
              <stop offset="14%" stopColor="#38bdf8" stopOpacity="0.95" />
              <stop offset="32%" stopColor="#0284c7" stopOpacity="1" />
              <stop offset="55%" stopColor="#034694" stopOpacity="1" />
              <stop offset="78%" stopColor="#062254" stopOpacity="1" />
              <stop offset="94%" stopColor="#020d24" stopOpacity="1" />
              <stop offset="100%" stopColor="#010614" stopOpacity="1" />
            </radialGradient>

            {/* Subtle soft specular highlight on the top surface */}
            <radialGradient id="specularGlow" cx="36%" cy="30%" r="28%">
              <stop offset="0%" stopColor="#ffffff" stopOpacity="0.65" />
              <stop offset="35%" stopColor="#67e8f9" stopOpacity="0.35" />
              <stop offset="100%" stopColor="#0284c7" stopOpacity="0" />
            </radialGradient>

            {/* Rim light at bottom right for spherical contour volume */}
            <radialGradient id="rimLight" cx="75%" cy="75%" r="45%">
              <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.18" />
              <stop offset="70%" stopColor="#0284c7" stopOpacity="0.05" />
              <stop offset="100%" stopColor="#000000" stopOpacity="0" />
            </radialGradient>

            {/* Inner dynamic plasma layer */}
            <filter id="orbNoise" x="0%" y="0%" width="100%" height="100%">
              <feTurbulence type="fractalNoise" baseFrequency="0.04" numOctaves="3" result="noise" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.1  0 0 0 0 0.5  0 0 0 0 0.9  0 0 0 0.35 0" />
              <feComposite in2="SourceGraphic" in="glare" operator="in" />
            </filter>
          </defs>

          {/* Base Sphere */}
          <circle cx="100" cy="100" r="97" fill="url(#sphereGrad)" />

          {/* Ambient bounce reflection on bottom-right contour */}
          <circle cx="100" cy="100" r="97" fill="url(#rimLight)" />

          {/* Top-left Specular Sheen */}
          <circle cx="100" cy="100" r="97" fill="url(#specularGlow)" />

          {/* Dynamic inner core pulse animation for thinking/speaking */}
          {isThinking && (
            <circle
              cx="100"
              cy="100"
              r="80"
              fill="none"
              stroke="#67e8f9"
              strokeWidth="1.5"
              strokeDasharray="12 8"
              className="animate-spin origin-center opacity-40"
            />
          )}

          {isSpeaking && (
            <circle
              cx="100"
              cy="100"
              r="90"
              fill="none"
              stroke="#38bdf8"
              strokeWidth="2"
              className="animate-pulse origin-center opacity-60"
            />
          )}
        </svg>

        {/* Ambient idle float wrapper */}
        <div className="absolute inset-0 rounded-full shadow-[inset_0_0_20px_rgba(255,255,255,0.15)] pointer-events-none" />
      </div>

      {/* Status indicator / telemetry readout below orb */}
      <div className="mt-6 flex flex-col items-center">
        {isThinking && (
          <div className="flex items-center space-x-2 text-cyan-300 font-mono text-xs tracking-widest uppercase animate-pulse">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
            <span>PRIYA Processing...</span>
          </div>
        )}

        {isSpeaking && (
          <div className="flex items-center space-x-1.5 text-sky-300 font-mono text-xs tracking-widest uppercase">
            <span className="w-1 h-3 bg-sky-400 animate-pulse" />
            <span className="w-1 h-4 bg-cyan-300 animate-pulse delay-75" />
            <span className="w-1 h-2 bg-sky-500 animate-pulse delay-150" />
            <span className="ml-1">Synthesizing Vocal Response</span>
          </div>
        )}

        {subtitle && !isThinking && !isSpeaking && (
          <div className="text-cyan-400/60 font-mono text-xs tracking-wider text-center max-w-sm truncate">
            {subtitle}
          </div>
        )}
      </div>
    </div>
  );
};
