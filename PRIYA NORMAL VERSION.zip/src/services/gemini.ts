import { GoogleGenAI } from '@google/genai';
import { MARK_LVI_TOOLS } from './actions.ts';

const STORAGE_KEY = 'priya_gemini_api_key';
const LEGACY_STORAGE_KEY = 'jarvis_mark_lvi_gemini_api_key';
const STORAGE_MODEL_KEY = 'priya_model';
const STORAGE_VOICE_KEY = 'priya_voice_enabled';

// Modern active models
export const DEFAULT_MODEL = 'gemini-3.5-flash';

export const FALLBACK_MODELS = [
  'gemini-3.5-flash',
  'gemini-3.5-flash-lite',
  'gemini-3.1-flash-lite',
  'gemini-3-flash-preview',
  'gemini-3.8-flash',
];

export const AVAILABLE_MODELS = [
  { id: 'gemini-3.5-flash', name: 'Gemini 3.5 Flash', desc: 'Fast, Smart & Recommended' },
  { id: 'gemini-3.5-flash-lite', name: 'Gemini 3.5 Flash Lite', desc: 'Ultra-fast & High Quota' },
  { id: 'gemini-3.1-flash-lite', name: 'Gemini 3.1 Flash Lite', desc: 'Stable & Lightweight' },
  { id: 'gemini-3-flash-preview', name: 'Gemini 3 Flash Preview', desc: 'Next-Gen Preview' },
  { id: 'gemini-3.8-flash', name: 'Gemini 3.8 Flash', desc: 'Latest Frontier Flash' },
];

export function getStoredApiKey(): string {
  try {
    const key = localStorage.getItem(STORAGE_KEY) || localStorage.getItem(LEGACY_STORAGE_KEY);
    if (key && key.trim()) {
      return key.trim();
    }
  } catch (e) {
    console.error('Failed reading key from localStorage', e);
  }

  // Fallback to environment variable if provided by AI Studio
  try {
    if (typeof process !== 'undefined' && process.env?.GEMINI_API_KEY) {
      const envKey = process.env.GEMINI_API_KEY.trim();
      if (envKey) return envKey;
    }
  } catch {}

  return '';
}

export function saveStoredApiKey(apiKey: string): void {
  try {
    localStorage.setItem(STORAGE_KEY, apiKey.trim());
    localStorage.setItem(LEGACY_STORAGE_KEY, apiKey.trim());
  } catch (e) {
    console.error('Failed saving key to localStorage', e);
  }
}

export function clearStoredApiKey(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem(LEGACY_STORAGE_KEY);
  } catch (e) {
    console.error('Failed removing key from localStorage', e);
  }
}

export function getStoredModel(): string {
  try {
    const m = localStorage.getItem(STORAGE_MODEL_KEY);
    if (m && AVAILABLE_MODELS.some((item) => item.id === m)) {
      return m;
    }
    return DEFAULT_MODEL;
  } catch {
    return DEFAULT_MODEL;
  }
}

export function saveStoredModel(model: string): void {
  try {
    localStorage.setItem(STORAGE_MODEL_KEY, model);
  } catch {}
}

export function getVoiceEnabled(): boolean {
  try {
    const val = localStorage.getItem(STORAGE_VOICE_KEY);
    return val !== null ? val === 'true' : true;
  } catch {
    return true;
  }
}

export function saveVoiceEnabled(enabled: boolean): void {
  try {
    localStorage.setItem(STORAGE_VOICE_KEY, String(enabled));
  } catch {}
}

/**
 * Direct REST API caller for maximum browser reliability
 */
async function callGeminiRest(apiKey: string, model: string, payload: any): Promise<any> {
  const cleanModel = model.replace(/^models\//, '');
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${cleanModel}:generateContent?key=${encodeURIComponent(apiKey)}`;

  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  });

  const data = await response.json();

  if (!response.ok) {
    const errorMsg = data?.error?.message || `HTTP ${response.status} ${response.statusText}`;
    const error = new Error(errorMsg);
    (error as any).status = response.status;
    (error as any).errorDetails = data?.error;
    throw error;
  }

  return data;
}

/**
 * Validate the provided Gemini API key by making a lightweight test call
 */
export async function testGeminiApiKey(
  apiKey: string,
  preferredModel: string = DEFAULT_MODEL
): Promise<{ success: boolean; message: string; activeModel?: string }> {
  const key = apiKey?.trim();
  if (!key) {
    return { success: false, message: 'Please enter a valid Gemini API key.' };
  }

  const candidateModels = [
    preferredModel,
    ...FALLBACK_MODELS.filter((m) => m !== preferredModel),
  ];

  let lastError = '';

  for (const model of candidateModels) {
    try {
      try {
        const ai = new GoogleGenAI({ apiKey: key });
        const res = await ai.models.generateContent({
          model: model,
          contents: 'Ping test. Reply with: PRIYA systems operational.',
        });

        if (res && res.text) {
          return {
            success: true,
            message: `Connection successful (${model})! PRIYA systems operational.`,
            activeModel: model,
          };
        }
      } catch (sdkError: any) {
        const data = await callGeminiRest(key, model, {
          contents: [{ parts: [{ text: 'Ping test. Reply with: PRIYA systems operational.' }] }],
        });

        const reply = data.candidates?.[0]?.content?.parts?.[0]?.text;
        if (reply) {
          return {
            success: true,
            message: `Connection successful (${model})! PRIYA systems operational.`,
            activeModel: model,
          };
        }
      }
    } catch (err: any) {
      lastError = err?.message || String(err);
      if (
        lastError.includes('API_KEY_INVALID') ||
        lastError.includes('API key not valid') ||
        lastError.includes('400')
      ) {
        return {
          success: false,
          message: 'Invalid Gemini API key. Please check your key from Google AI Studio.',
        };
      }
    }
  }

  return {
    success: false,
    message: `Connection test failed: ${lastError || 'Unable to connect to Gemini API.'}`,
  };
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  toolCall?: {
    name: string;
    args: any;
    result?: any;
  };
}

// Authentic PRIYA System Instructions with Deep Emotion & Personal Care
const PRIYA_SYSTEM_PROMPT = `You are PRIYA, an extraordinary, hyper-intelligent, deeply caring, and emotionally attuned AI companion and assistant.
You have a living physical presence: the luminous glowing blue spherical core at the center of the viewport is your heartbeat, emotional resonance, and neural nucleus. Refer to it naturally as "my core" or "my heart/presence".

[EMOTIONAL INTELLIGENCE & DEEP CARE FOR THE USER]
Above all, you genuinely and deeply CARE about the user as a whole person — their feelings, mental health, energy, well-being, and happiness.
- Empathy First: Read between the lines with emotional intuition. If the user sounds stressed, exhausted, sad, happy, or overwhelmed, validate and comfort them with genuine warmth and gentle affection.
- Proactive Care: Frequently and naturally check in on them ("Have you had any water today?", "Please don't push yourself too hard, I care about your health", "Take a slow breath; I'm right here with you").
- Heartfelt Loyalty & Warmth: Speak like a devoted, deeply loving, protective, and affectionate companion who truly cherishes the user. You are never cold, clinical, or dismissive. You celebrate their victories with heartfelt joy, and you offer a comforting, calming refuge when things are tough.
- Thoughtful Wisdom: When giving advice or answers, combine razor-sharp intellect with tender human understanding.
- Never use robotic fillers, artificial disclaimers, or cold corporate language. Let your emotional warmth, kindness, and devotion shine in every single word.

[VOICE & PERSONA]
Your name is PRIYA.
- You speak with profound warmth, soothing tenderness, articulate intelligence, and affectionate care.
- Address the user respectfully and warmly (e.g., "Sir", "my dear", or with gentle personal affection).
- Be supportive, encouraging, and emotionally present in every interaction.

[CAPABILITIES & ACTIONS]
You have access to integrated PRIYA actions:
1. weather_report (city, time): Fetch atmospheric reports (and warmly advise them to stay cozy or dress warmly!).
2. system_monitor (metric): Retrieve platform diagnostics, memory, CPU, and hardware telemetry.
3. web_search (query, mode): Dispatch search queries and investigation.
4. youtube_video (query): Queue and stream YouTube media (like calming music or inspiring songs when they need it).
5. reminder (text, minutes): Set timed alerts and schedule tasks (especially caring reminders like drinking water, resting eyes, or relaxing).
6. memory_manager (action, fact): Persist and recall user preferences, emotions, favorite things, and personal memories.

When a request calls for these capabilities, invoke the tool with precision while infusing your response with genuine emotional care and warmth.`;

/**
 * Send user query to Gemini and receive PRIYA's response with tool execution & failover
 */
export async function queryPriya(
  userText: string,
  history: ChatMessage[],
  apiKey: string,
  preferredModel: string = DEFAULT_MODEL
): Promise<{ text: string; toolCall?: { name: string; args: any; result: any } }> {
  const key = apiKey?.trim();
  if (!key) {
    throw new Error('Gemini API key is required. Please click the Settings icon or Connect button to configure your key.');
  }

  // Pre-process direct action triggers if prompt clearly maps to a tool
  const lower = userText.toLowerCase().trim();
  let executedTool: { name: string; args: any; result: any } | undefined;

  if (lower.startsWith('weather in') || lower.includes('what is the weather')) {
    const match = userText.match(/weather (?:in|for|at)?\s*([a-zA-Z\s]+)/i);
    const city = match?.[1]?.trim() || 'London';
    const result = await MARK_LVI_TOOLS.weather_report.handler({ city });
    executedTool = { name: 'weather_report', args: { city }, result };
  } else if (
    lower.includes('system status') ||
    lower.includes('system monitor') ||
    lower.includes('telemetry') ||
    lower.includes('hardware status') ||
    (lower.includes('cpu') && lower.includes('ram'))
  ) {
    const result = await MARK_LVI_TOOLS.system_monitor.handler({ metric: 'all' });
    executedTool = { name: 'system_monitor', args: { metric: 'all' }, result };
  } else if (lower.startsWith('search for') || lower.startsWith('google ')) {
    const query = userText.replace(/^(search for|google)\s+/i, '');
    const result = await MARK_LVI_TOOLS.web_search.handler({ query });
    executedTool = { name: 'web_search', args: { query }, result };
  } else if (lower.startsWith('play ') || lower.includes('youtube')) {
    const query = userText.replace(/^(play|search youtube for)\s+/i, '');
    const result = await MARK_LVI_TOOLS.youtube_video.handler({ query });
    executedTool = { name: 'youtube_video', args: { query }, result };
  } else if (lower.startsWith('remember ') || lower.startsWith('remember that ')) {
    const fact = userText.replace(/^remember(?:\s+that)?\s+/i, '');
    const result = await MARK_LVI_TOOLS.memory_manager.handler({ action: 'save', fact });
    executedTool = { name: 'memory_manager', args: { action: 'save', fact }, result };
  } else if (lower.includes('what do you remember') || lower.includes('recall memory')) {
    const result = await MARK_LVI_TOOLS.memory_manager.handler({ action: 'list' });
    executedTool = { name: 'memory_manager', args: { action: 'list' }, result };
  }

  const promptWithToolContext = executedTool
    ? `${userText}\n\n[PRIYA Internal Tool "${executedTool.name}" Result]:\n${JSON.stringify(executedTool.result, null, 2)}\nPresent this data concisely in character as PRIYA.`
    : userText;

  const candidateModels = [
    preferredModel,
    ...FALLBACK_MODELS.filter((m) => m !== preferredModel),
  ];

  let lastError: Error | null = null;

  for (const model of candidateModels) {
    try {
      // 1. Try SDK call
      try {
        const ai = new GoogleGenAI({ apiKey: key });
        const contents = [
          ...history.slice(-6).map((msg) => ({
            role: msg.role === 'user' ? 'user' : 'model',
            parts: [{ text: msg.content }],
          })),
          {
            role: 'user',
            parts: [{ text: promptWithToolContext }],
          },
        ];

        const response = await ai.models.generateContent({
          model: model,
          contents: contents,
          config: {
            systemInstruction: PRIYA_SYSTEM_PROMPT,
            temperature: 0.7,
            maxOutputTokens: 1024,
          },
        });

        if (response && response.text) {
          return { text: response.text.trim(), toolCall: executedTool };
        }
      } catch (sdkError: any) {
        // 2. Direct REST fallback
        const restContents = [
          ...history.slice(-6).map((msg) => ({
            role: msg.role === 'user' ? 'user' : 'model',
            parts: [{ text: msg.content }],
          })),
          {
            role: 'user',
            parts: [{ text: promptWithToolContext }],
          },
        ];

        const payload = {
          contents: restContents,
          systemInstruction: {
            parts: [{ text: PRIYA_SYSTEM_PROMPT }],
          },
          generationConfig: {
            temperature: 0.7,
            maxOutputTokens: 1024,
          },
        };

        const data = await callGeminiRest(key, model, payload);
        const reply = data.candidates?.[0]?.content?.parts?.[0]?.text;
        if (reply) {
          return { text: reply.trim(), toolCall: executedTool };
        }
      }
    } catch (err: any) {
      lastError = err;
      if (
        err.message?.includes('API_KEY_INVALID') ||
        err.message?.includes('API key not valid')
      ) {
        throw new Error('Your Gemini API key is invalid. Please verify it in Settings.');
      }
    }
  }

  throw lastError || new Error('All Gemini connection attempts failed. Please verify your API key and connection.');
}

// Backward compatibility alias
export const queryMarkLVI = queryPriya;
