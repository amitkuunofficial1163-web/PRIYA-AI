/**
 * PRIYA Neural Voice Engine
 * Combines Google Gemini Studio Neural TTS (24kHz PCM) with browser AudioContext
 * and Web Speech API fallback. Guaranteed voice playback across all browsers & iframes.
 */

let audioCtx: AudioContext | null = null;
let activeSourceNode: AudioBufferSourceNode | null = null;

export function getAudioContext(): AudioContext {
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    audioCtx = new AudioContextClass();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

/**
 * Prime and unlock browser audio on user gesture
 */
export function unlockAudio(): void {
  try {
    const ctx = getAudioContext();
    if (ctx.state === 'suspended') {
      ctx.resume();
    }
  } catch {}

  if ('speechSynthesis' in window) {
    try {
      window.speechSynthesis.resume();
    } catch {}
  }
}

/**
 * Stop any active playback
 */
export function stopSpeaking(): void {
  if (activeSourceNode) {
    try {
      activeSourceNode.stop();
      activeSourceNode.disconnect();
    } catch {}
    activeSourceNode = null;
  }

  if ('speechSynthesis' in window) {
    try {
      window.speechSynthesis.cancel();
    } catch {}
  }
}

/**
 * Play a high-tech activation chime
 */
export function playChime(type: 'activate' | 'response' = 'activate'): void {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.connect(gain);
    gain.connect(ctx.destination);

    if (type === 'activate') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(523.25, now); // C5
      osc.frequency.exponentialRampToValueAtTime(783.99, now + 0.12); // G5
      gain.gain.setValueAtTime(0.06, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
      osc.start(now);
      osc.stop(now + 0.22);
    } else {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(659.25, now); // E5
      osc.frequency.exponentialRampToValueAtTime(880.00, now + 0.1); // A5
      gain.gain.setValueAtTime(0.06, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
      osc.start(now);
      osc.stop(now + 0.2);
    }
  } catch {}
}

/**
 * Convert 16-bit PCM base64 string to an AudioBuffer and play via Web Audio API
 */
export function playPcmBase64(base64: string, sampleRate = 24000): Promise<void> {
  return new Promise((resolve) => {
    try {
      stopSpeaking();
      const ctx = getAudioContext();
      if (ctx.state === 'suspended') {
        ctx.resume();
      }

      const binary = atob(base64);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) {
        bytes[i] = binary.charCodeAt(i);
      }

      // Convert 16-bit signed PCM to Float32 [-1.0, 1.0]
      const pcm16 = new Int16Array(bytes.buffer);
      const float32 = new Float32Array(pcm16.length);
      for (let i = 0; i < pcm16.length; i++) {
        float32[i] = pcm16[i] / 32768.0;
      }

      const buffer = ctx.createBuffer(1, float32.length, sampleRate);
      buffer.copyToChannel(float32, 0);

      const source = ctx.createBufferSource();
      activeSourceNode = source;
      source.buffer = buffer;
      source.connect(ctx.destination);

      source.onended = () => {
        if (activeSourceNode === source) {
          activeSourceNode = null;
        }
        resolve();
      };

      source.start(0);
    } catch (err) {
      console.error('PCM audio playback error', err);
      resolve();
    }
  });
}

const TTS_MODELS = [
  'gemini-2.5-flash-preview-tts',
  'gemini-3.1-flash-tts-preview',
  'gemini-3.8-flash-tts',
];

/**
 * Synthesize speech using Gemini Neural TTS API
 */
async function fetchGeminiTtsAudio(
  text: string,
  apiKey: string,
  voiceName: string = 'Kore'
): Promise<string | null> {
  const clean = text
    .replace(/[*#`_~>]/g, ' ')
    .replace(/https?:\/\/\S+/g, 'link')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 350);

  if (!clean || !apiKey) return null;

  for (const model of TTS_MODELS) {
    try {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(apiKey)}`;
      const payload = {
        contents: [{ parts: [{ text: clean }] }],
        generationConfig: {
          responseModalities: ['AUDIO'],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: {
                voiceName: voiceName,
              },
            },
          },
        },
      };

      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (res.ok) {
        const data = await res.json();
        const base64Audio = data.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        if (base64Audio) {
          return base64Audio;
        }
      }
    } catch (e) {
      console.warn(`TTS fetch with ${model} failed, trying next:`, e);
    }
  }

  return null;
}

/**
 * Fallback to browser SpeechSynthesis if Neural TTS fails or offline
 */
function speakBrowserSpeech(
  text: string,
  callbacks?: { onStart?: () => void; onEnd?: () => void }
): void {
  if (!('speechSynthesis' in window)) {
    callbacks?.onEnd?.();
    return;
  }

  try {
    window.speechSynthesis.cancel();
    if (window.speechSynthesis.paused) {
      window.speechSynthesis.resume();
    }

    const clean = text.replace(/[*#`_~>]/g, ' ').slice(0, 280);
    const utterance = new SpeechSynthesisUtterance(clean);

    const voices = window.speechSynthesis.getVoices();
    const femaleVoice =
      voices.find((v) => /female|priya|samantha|karen|veena/i.test(v.name) && v.lang.startsWith('en')) ||
      voices.find((v) => v.lang.startsWith('en'));

    if (femaleVoice) {
      utterance.voice = femaleVoice;
    }

    utterance.rate = 1.0;
    utterance.pitch = 1.05;

    utterance.onstart = () => callbacks?.onStart?.();
    utterance.onend = () => callbacks?.onEnd?.();
    utterance.onerror = () => callbacks?.onEnd?.();

    window.speechSynthesis.speak(utterance);
  } catch {
    callbacks?.onEnd?.();
  }
}

/**
 * Master speak function for PRIYA:
 * 1. Unlocks audio context
 * 2. Fetches lifelike neural voice from Gemini Studio TTS
 * 3. Plays via Web Audio PCM
 * 4. Gracefully falls back to browser SpeechSynthesis if needed
 */
export async function speakPriya(
  text: string,
  apiKey: string,
  callbacks?: {
    onStart?: () => void;
    onEnd?: () => void;
    onError?: (err?: any) => void;
  }
): Promise<void> {
  unlockAudio();
  playChime('response');

  callbacks?.onStart?.();

  try {
    // 1. Attempt Gemini Neural Studio TTS
    if (apiKey) {
      const pcmBase64 = await fetchGeminiTtsAudio(text, apiKey, 'Kore');
      if (pcmBase64) {
        await playPcmBase64(pcmBase64, 24000);
        callbacks?.onEnd?.();
        return;
      }
    }

    // 2. Fallback to browser SpeechSynthesis
    speakBrowserSpeech(text, {
      onStart: callbacks?.onStart,
      onEnd: callbacks?.onEnd,
    });
  } catch (err) {
    console.error('Priya speech error:', err);
    speakBrowserSpeech(text, {
      onStart: callbacks?.onStart,
      onEnd: callbacks?.onEnd,
    });
  }
}
